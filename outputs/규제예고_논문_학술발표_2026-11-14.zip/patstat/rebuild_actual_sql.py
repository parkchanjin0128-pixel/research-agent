from pathlib import Path
import json,re,hashlib
P=Path(__file__).parent
q=json.loads((P/'queries.json').read_text())
fr=json.loads((P/'firm_dose_raw.json').read_text())
dataset=re.search(r'`([^`]+)\.tls206_person`',fr['query']).group(1)
def fq(n):return '`'+dataset+'.'+n+'`'
fmt={k:fq(n) for k,n in {'A':'tls201_appln','I':'tls209_appln_ipc','PA':'tls207_pers_appln','P':'tls206_person','PUB':'tls211_pat_publn','CIT':'tls212_citation','PP':'tls227_pers_publn'}.items()}
hwc="SELECT DISTINCT pub.appln_id,TRIM(p.person_ctry_code) AS country FROM {PP} pp JOIN {PUB} pub USING(pat_publn_id) JOIN {P} p USING(person_id) WHERE pp.applt_seq_nr>0 AND pub.publn_date BETWEEN DATE'2013-01-01' AND DATE'2017-12-31' AND TRIM(p.person_ctry_code) IN ('CN','US','JP','KR','DE')"
hd=q['dose']; a=hd.index('wc AS (');b=hd.index('),\nsource AS (',a)
hd=(hd[:a]+'wc AS ('+hwc+hd[b:]).format(**fmt)
fs=fr['query'].split(',pairdoc AS (',1)[0]
hfs=fs.replace('pa USING(person_id) JOIN '+fq('tls201_appln')+' a USING(appln_id)', 'pa USING(person_id) JOIN '+fq('tls211_pat_publn')+' hp USING(pat_publn_id) JOIN '+fq('tls201_appln')+' a USING(appln_id)').replace(fq('tls207_pers_appln'),fq('tls227_pers_publn')).replace('WHERE pa.applt_seq_nr>0',"WHERE hp.publn_date BETWEEN DATE'2013-01-01' AND DATE'2017-12-31' AND pa.applt_seq_nr>0")
hf=(hfs+',pairdoc AS ('+q['dose'].split('pairdoc AS (',1)[1]).format(**fmt)
ib=q['support'].split('SELECT m.unit,m.label,c.country,EXTRACT',1)[0].replace("WHERE a.appln_auth='WO' AND a.docdb_family_id>0","WHERE a.docdb_family_id>0")
ip=ib+""", family_map AS (SELECT DISTINCT unit,label,docdb_family_id FROM members), f0 AS (SELECT a.docdb_family_id,MIN(a.earliest_publn_date) AS first_public,COUNT(DISTINCT IF(a.appln_auth!='WO',a.appln_auth,NULL)) offices,COUNTIF(a.appln_auth IN ('CN','US','JP','KR','EP')) ip5_apps,ARRAY_AGG(STRUCT(a.earliest_publn_date,a.earliest_pat_publn_id) ORDER BY a.earliest_publn_date,a.earliest_pat_publn_id LIMIT 1)[OFFSET(0)].earliest_pat_publn_id AS doc FROM {A} a JOIN (SELECT DISTINCT docdb_family_id FROM family_map)f USING(docdb_family_id) WHERE a.earliest_publn_date BETWEEN DATE'1800-01-01' AND DATE'2017-12-31' GROUP BY 1), eligible AS (SELECT * FROM f0 WHERE first_public BETWEEN DATE'2013-01-01' AND DATE'2017-12-31' AND offices>=2 AND ip5_apps>0), cc AS (SELECT pp.pat_publn_id,COUNT(DISTINCT NULLIF(TRIM(p.person_ctry_code),'')) n_country,COUNT(DISTINCT IF(TRIM(p.person_ctry_code)='US','US',NULL)) n_us FROM {PP} pp JOIN {P} p USING(person_id) JOIN (SELECT DISTINCT doc FROM eligible)x ON pp.pat_publn_id=x.doc WHERE pp.applt_seq_nr>0 GROUP BY 1) SELECT m.unit,m.label,COUNT(*) families,COUNTIF(cc.n_country>0) known_families,SUM(IFNULL(SAFE_DIVIDE(cc.n_us,cc.n_country),0)) known_us_mass FROM family_map m JOIN eligible e USING(docdb_family_id) LEFT JOIN cc ON cc.pat_publn_id=e.doc GROUP BY 1,2 ORDER BY 1"""
more={'historical_technology':hd,'historical_firms':hf,'ip5':ip.format(**fmt)}
expected=json.loads((P/'historical_source_and_ip5_raw.json').read_text())['query_shas']
for k,s in more.items():
 assert hashlib.sha256(s.encode()).hexdigest()==expected[k],k
 (P/(k+'_actual.sql')).write_text(s,encoding='utf-8')
(P/'actual_sql_integrity.json').write_text(json.dumps({'hashes':expected,'reconstructed_bytes_match_observed_query_shas':True},indent=2))
print('All three actual SQL byte hashes match TIP execution output.')
