"""Run in logged-in EPO TIP notebook. Catalogue only; no new outcome rows."""
from epo.tipdata.patstat import PatstatClient
import datetime,hashlib,json,re
patstat=PatstatClient(env='PROD')
dataset=patstat.full_dataset.strip(chr(96)).replace(':','.')
assert re.fullmatch(r'[A-Za-z0-9_-]+[.][A-Za-z0-9_]+',dataset)
def fq(n):
 assert re.fullmatch(r'tls[0-9]{3}_[a-z_]+',n)
 return chr(96)+dataset+'.'+n+chr(96)
def query_rows(sql):
 def builtin(v):
  if hasattr(v,'items'):return {k:builtin(x) for k,x in v.items()}
  if isinstance(v,(list,tuple)):return [builtin(x) for x in v]
  if isinstance(v,(datetime.datetime,datetime.date)):return v.isoformat()
  return v
 return [builtin(r) for r in patstat.sql_query(sql,use_legacy_sql=False)]
meta=query_rows('SELECT table_name,column_name,data_type FROM '+chr(96)+dataset+'.INFORMATION_SCHEMA.COLUMNS'+chr(96)+" WHERE LOWER(table_name) IN ('tls201_appln','tls206_person','tls207_pers_appln','tls209_appln_ipc','tls211_pat_publn','tls212_citation','tls227_pers_publn') ORDER BY table_name,ordinal_position")
print('NOV14_META_JSON',json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'dataset_label':dataset.split('.')[-1],'dataset_sha256':hashlib.sha256(dataset.encode()).hexdigest(),'schema':meta}),flush=True)
try:
 prov=query_rows('SELECT table_name,table_type,creation_time FROM '+chr(96)+dataset+'.INFORMATION_SCHEMA.TABLES'+chr(96)+" WHERE LOWER(table_name) IN ('tls201_appln','tls206_person','tls209_appln_ipc','tls212_citation')")
 print('NOV14_TABLE_PROVENANCE',json.dumps(prov),flush=True)
except Exception as exc:print('NOV14_TABLE_PROVENANCE_ERROR',type(exc).__name__,flush=True)
