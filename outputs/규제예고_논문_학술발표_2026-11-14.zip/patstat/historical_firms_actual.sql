WITH firm_map AS (SELECT * FROM UNNEST([STRUCT('BIDU_issuer' AS unit,'issuer' AS label,'BAIDUINC' AS exact_key),STRUCT('BIDU_group' AS unit,'group' AS label,'BAIDUINC' AS exact_key),STRUCT('BIDU_group' AS unit,'group' AS label,'BAIDUONLINENETWORKTECHNOLOGYBEIJINGCOLTD' AS exact_key),STRUCT('BIDU_group' AS unit,'group' AS label,'BEIJINGBAIDUNETCOMSCIENCETECHNOLOGYCOLTD' AS exact_key),STRUCT('BIDU_group' AS unit,'group' AS label,'BEIJINGPERUSALTECHNOLOGYCOLTD' AS exact_key),STRUCT('BABA_issuer' AS unit,'issuer' AS label,'ALIBABAGROUPHOLDINGLIMITED' AS exact_key),STRUCT('BABA_issuer' AS unit,'issuer' AS label,'ALIBABAGROUPHOLDINGLTD' AS exact_key),STRUCT('BABA_group' AS unit,'group' AS label,'ALIBABAGROUPHOLDINGLIMITED' AS exact_key),STRUCT('BABA_group' AS unit,'group' AS label,'ALIBABAGROUPHOLDINGLTD' AS exact_key),STRUCT('BABA_group' AS unit,'group' AS label,'ALIBABAGROUPSERVICESLIMITED' AS exact_key),STRUCT('BABA_group' AS unit,'group' AS label,'ALIBABAGROUPSERVICESLTD' AS exact_key),STRUCT('BABA_group' AS unit,'group' AS label,'ALIBABACHINACOLTD' AS exact_key),STRUCT('BABA_group' AS unit,'group' AS label,'ALIBABACHINATECHNOLOGYCOLTD' AS exact_key),STRUCT('BABA_group' AS unit,'group' AS label,'TAOBAOCHINASOFTWARECOLTD' AS exact_key),STRUCT('BABA_group' AS unit,'group' AS label,'ZHEJIANGTMALLTECHNOLOGYCOLTD' AS exact_key),STRUCT('BABA_group' AS unit,'group' AS label,'ZHEJIANGTAOBAONETWORKCOLTD' AS exact_key),STRUCT('BABA_group' AS unit,'group' AS label,'ZHEJIANGTMALLNETWORKCOLTD' AS exact_key),STRUCT('BABA_group' AS unit,'group' AS label,'HANGZHOUALIBABAADVERTISINGCOLTD' AS exact_key),STRUCT('BABA_group' AS unit,'group' AS label,'ALIBABACLOUDCOMPUTINGLTD' AS exact_key),STRUCT('JD_issuer' AS unit,'issuer' AS label,'JDCOMINC' AS exact_key),STRUCT('JD_group' AS unit,'group' AS label,'JDCOMINC' AS exact_key),STRUCT('JD_group' AS unit,'group' AS label,'BEIJINGJINGDONGCENTURYTRADECOLTD' AS exact_key),STRUCT('JD_group' AS unit,'group' AS label,'BEIJINGJINGDONGSHANGKEINFORMATIONTECHNOLOGYCOLTD' AS exact_key),STRUCT('JD_group' AS unit,'group' AS label,'JIANGSUJINGDONGINFORMATIONTECHNOLOGYCOLTD' AS exact_key),STRUCT('JD_group' AS unit,'group' AS label,'SHANGHAISHENGDAYUANINFORMATIONTECHNOLOGYCOLTD' AS exact_key),STRUCT('JD_group' AS unit,'group' AS label,'BEIJINGJINGDONG360DEGREEECOMMERCECOLTD' AS exact_key),STRUCT('JD_group' AS unit,'group' AS label,'JIANGSUYUANZHOUECOMMERCECOLTD' AS exact_key),STRUCT('NTES_issuer' AS unit,'issuer' AS label,'NETEASEINC' AS exact_key),STRUCT('NTES_group' AS unit,'group' AS label,'NETEASEINC' AS exact_key),STRUCT('NTES_group' AS unit,'group' AS label,'NETEASEHANGZHOUNETWORKCOLTD' AS exact_key),STRUCT('NTES_group' AS unit,'group' AS label,'GUANGZHOUBOGUANTELECOMMUNICATIONTECHNOLOGYCOLTD' AS exact_key),STRUCT('NTES_group' AS unit,'group' AS label,'NETEASEINFORMATIONTECHNOLOGYBEIJINGCOLTD' AS exact_key),STRUCT('NTES_group' AS unit,'group' AS label,'GUANGZHOUNETEASECOMPUTERSYSTEMCOLTD' AS exact_key),STRUCT('NTES_group' AS unit,'group' AS label,'HANGZHOUNETEASELEIHUONETWORKCOLTD' AS exact_key)])), source AS (SELECT DISTINCT m.unit,m.label,a.docdb_family_id,a.appln_id FROM firm_map m JOIN `p-epo-tip-prj-3a1f.p_epo_tip_euwe4_bqd_patstatb.tls206_person` p ON REGEXP_REPLACE(UPPER(p.person_name),r'[^A-Z0-9]','')=m.exact_key JOIN `p-epo-tip-prj-3a1f.p_epo_tip_euwe4_bqd_patstatb.tls227_pers_publn` pa USING(person_id) JOIN `p-epo-tip-prj-3a1f.p_epo_tip_euwe4_bqd_patstatb.tls211_pat_publn` hp USING(pat_publn_id) JOIN `p-epo-tip-prj-3a1f.p_epo_tip_euwe4_bqd_patstatb.tls201_appln` a USING(appln_id) WHERE hp.publn_date BETWEEN DATE'2013-01-01' AND DATE'2017-12-31' AND pa.applt_seq_nr>0 AND a.docdb_family_id>0 AND a.earliest_publn_date BETWEEN DATE'2013-01-01' AND DATE'2017-12-31'),pairdoc AS (
 SELECT s.unit,s.label,s.docdb_family_id AS source_family,
 ta.docdb_family_id AS target_family,t.pat_publn_id AS target_doc,t.publn_date,
 LOGICAL_OR(REGEXP_CONTAINS(UPPER(c.citn_origin),r'(^|[^A-Z])APP([^A-Z]|$)')) AS app
 FROM source s JOIN `p-epo-tip-prj-3a1f.p_epo_tip_euwe4_bqd_patstatb.tls211_pat_publn` sp ON sp.appln_id=s.appln_id
 JOIN `p-epo-tip-prj-3a1f.p_epo_tip_euwe4_bqd_patstatb.tls212_citation` c ON c.pat_publn_id=sp.pat_publn_id
 LEFT JOIN `p-epo-tip-prj-3a1f.p_epo_tip_euwe4_bqd_patstatb.tls211_pat_publn` cd ON cd.pat_publn_id=c.cited_pat_publn_id AND c.cited_pat_publn_id>0
 JOIN `p-epo-tip-prj-3a1f.p_epo_tip_euwe4_bqd_patstatb.tls201_appln` ta ON ta.appln_id=COALESCE(cd.appln_id,NULLIF(c.cited_appln_id,0))
 JOIN `p-epo-tip-prj-3a1f.p_epo_tip_euwe4_bqd_patstatb.tls211_pat_publn` t ON t.appln_id=ta.appln_id
 WHERE sp.publn_date BETWEEN DATE'2013-01-01' AND DATE'2017-12-31'
 AND t.publn_date<=DATE'2017-12-31' AND t.publn_date>=DATE'1800-01-01'
 AND ta.docdb_family_id>0 AND ta.docdb_family_id!=s.docdb_family_id
 AND (c.cited_pat_publn_id=0 OR c.cited_pat_publn_id IS NULL OR t.pat_publn_id=c.cited_pat_publn_id)
 GROUP BY 1,2,3,4,5,6
), pair AS (
 SELECT unit,label,source_family,target_family,
 ARRAY_AGG(STRUCT(target_doc,publn_date) ORDER BY publn_date,target_doc LIMIT 1)[OFFSET(0)].target_doc AS target_doc,
 LOGICAL_OR(app) AS app FROM pairdoc GROUP BY 1,2,3,4
), target_country AS (
 SELECT pp.pat_publn_id,COUNT(DISTINCT NULLIF(TRIM(p.person_ctry_code),'')) AS n_country,
 COUNT(DISTINCT IF(TRIM(p.person_ctry_code)='US','US',NULL)) AS n_us
 FROM `p-epo-tip-prj-3a1f.p_epo_tip_euwe4_bqd_patstatb.tls227_pers_publn` pp JOIN `p-epo-tip-prj-3a1f.p_epo_tip_euwe4_bqd_patstatb.tls206_person` p USING(person_id)
 JOIN (SELECT DISTINCT target_doc FROM pair) x ON x.target_doc=pp.pat_publn_id
 WHERE pp.applt_seq_nr>0 GROUP BY 1
), d AS (SELECT pair.*,IFNULL(tc.n_country,0) n_country,
 SAFE_DIVIDE(tc.n_us,tc.n_country) AS us_fraction FROM pair
 LEFT JOIN target_country tc ON tc.pat_publn_id=pair.target_doc),
variants AS (SELECT *,v AS variant FROM d CROSS JOIN UNNEST(['ALL','APP'])v WHERE v='ALL' OR app),
agg AS (SELECT unit,label,variant,COUNT(*) AS pairs,
 COUNT(DISTINCT source_family) AS citing_families,COUNTIF(n_country>0) AS known_pairs,
 SUM(IFNULL(us_fraction,0)) AS known_us_mass FROM variants GROUP BY 1,2,3),
ns AS (SELECT unit,label,COUNT(DISTINCT docdb_family_id) AS source_families FROM source GROUP BY 1,2)
SELECT ns.*,v AS variant,IFNULL(a.pairs,0) pairs,IFNULL(a.citing_families,0) citing_families,
 IFNULL(a.known_pairs,0) known_pairs,IFNULL(a.known_us_mass,0) known_us_mass
FROM ns CROSS JOIN UNNEST(['ALL','APP'])v LEFT JOIN agg a ON a.unit=ns.unit AND a.variant=v
ORDER BY unit,variant
