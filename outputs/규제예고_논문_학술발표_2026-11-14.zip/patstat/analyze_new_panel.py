"""Actual new 18-unit panel. Observational dose projections, not causal DiD."""
from pathlib import Path
import sys,json,csv,hashlib,re
import numpy as np
R=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(R/'work/research-python-packages'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).parent; O=P.parent/'analysis';O.mkdir(exist_ok=True)
units=['N01','N02','N03','N04','N05','N06','N07','N08','N09','N10','N11','N12','P03','P04','P05','P06','P_ADDITIVE_UNION','P_NEURAL_GENETIC_UNION']
countries=['CN','US','JP','KR','DE'];months=[f'{y}-{m:02}' for y in range(2010,2020) for m in range(1,13)]
data=(P/'public_panel_u16.bin').read_bytes()
assert hashlib.sha256(data).hexdigest()=='e44d713c6db257670ad5460e855fe1809d605caf6d232df9cefada97135fe0d6'
Y=np.frombuffer(data,dtype='<u2').reshape(18,5,120).astype(float)
raw=json.loads((P/'historical_source_and_ip5_raw.json').read_text())
def rows(x):return [dict(zip(x['columns'],r)) for r in x['rows']]
dose=rows(raw['historical_technology']);ip5=rows(raw['ip5'])
support=rows(json.loads((P/'public_support_raw.json').read_text()))
sup={(r['unit'],r['country'],r['year']):r['families'] for r in support}
write=lambda name,rs:write_csv(O/name,rs)
def write_csv(p,rs):
 if not rs:return
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
summ=[]
for u in units:
 counts=[sup.get((u,c,y),0) for c in countries for y in range(2010,2016)]
 rr={'unit':u,'listed':int(u.startswith('P')),'pre_cells_30':len(counts),'pre_cell_min':min(counts),'pre_cells_lt5':sum(x<5 for x in counts),'passes_each_country_year_5':all(x>=5 for x in counts)}
 for v in ['ALL','APP']:
  a=next((r for r in dose if r['unit']==u and r['variant']==v),{})
  n=a.get('known_pairs',0);pairs=a.get('pairs',0);mass=a.get('known_us_mass',0)
  rr.update({v+'_source_families':a.get('source_families',0),v+'_pairs':pairs,v+'_known_pairs':n,v+'_B_observed_countries':mass/n if n else None,
   v+'_conditional_lower':mass/pairs if pairs else None,v+'_conditional_upper':(mass+pairs-n)/pairs if pairs else None})
 a=next(r for r in ip5 if r['unit']==u);n=a['known_families'];mass=a['known_us_mass'];total=a['families']
 rr.update({'IP5_families':total,'IP5_known_families':n,'IP5_B_observed_countries':mass/n if n else None,'IP5_conditional_lower':mass/total,'IP5_conditional_upper':(mass+total-n)/total})
 summ.append(rr)
write('technology_support_and_dose.csv',summ)
write('monthly_family_counts.csv',[{'unit':u,'country':c,'month':t,'families':int(Y[k,j,m])} for k,u in enumerate(units) for j,c in enumerate(countries) for m,t in enumerate(months)])
# R cancels technology-time effects under the maintained additive country model.
# Fixed unit baseline is 2017 average. Separate listed/nonlisted intercepts permit
# the lower-order China x listed x time contrast. Slopes use B/0.1 units.
logy=np.log1p(Y);Rkt=logy[:,0,:]-logy[:,1:,:].mean(axis=1)
arms=np.array([int(u.startswith('P')) for u in units]);baseline=np.arange(84,96)
specs={};series=[];summaries=[]
def estimate(B,keep,base=baseline,Rvalue=Rkt):
 vals=Rvalue-Rvalue[:,base].mean(axis=1,keepdims=True)
 X=np.column_stack([1-arms[keep],arms[keep],(1-arms[keep])*B[keep]/.1,arms[keep]*B[keep]/.1])
 assert np.linalg.matrix_rank(X)==4
 co=np.linalg.lstsq(X,vals[keep,:],rcond=None)[0]
 return co[3]-co[2],co[3],co[2]
for name,col,mincol in [('citation_ALL','ALL_B_observed_countries','ALL_known_pairs'),('public_multi_office_US_share','IP5_B_observed_countries','IP5_known_families')]:
 B=np.array([r[col] if r[col] is not None else np.nan for r in summ]);keep=np.isfinite(B)&(np.array([r[mincol] for r in summ])>=20)
 support_range={str(g):[float(B[keep&(arms==g)].min()),float(B[keep&(arms==g)].max())] for g in [0,1]}
 lo=max(x[0] for x in support_range.values());hi=min(x[1] for x in support_range.values())
 choices={'untrimmed_diagnostic':keep}
 if lo<=hi:choices['common_point_range_diagnostic']=keep&(B>=lo)&(B<=hi)
 for trim,sel in choices.items():
  d,l,n=estimate(B,sel);key=name+'__'+trim;specs[key]=(B,sel,d)
  for i,t in enumerate(months):series.append({'specification':key,'month':t,'theta_listed_minus_nonlisted':float(d[i]),'listed_slope':float(l[i]),'nonlisted_slope':float(n[i])})
  clean=np.arange(107,112) # December2018--April2019, before May16Huawei, not all restrictions absent
  x=np.arange(120);train=x<84;hold=(x>=84)&(x<96)
  Z=np.column_stack([np.ones(120),x/12]+[(x%12==m).astype(float) for m in range(1,12)])
  coef=np.linalg.lstsq(Z[train],d[train],rcond=None)[0];err=d[hold]-Z[hold]@coef
  fake=[]
  for year in [2013,2014,2015,2016]:
   b=np.arange((year-1-2010)*12,(year-2010)*12);f=np.arange((year-2010)*12+11,(year-2010)*12+16)
   dd,*_=estimate(B,sel,base=b);fake.append({'year_december':year,'contrast':float(dd[f].mean())})
  # Permuted dose is a reference diagnostic; this is not an assigned treatment.
  rng=np.random.default_rng(20261114);ref=[]
  for rep in range(4999):
   perm=B.copy()
   for g in [0,1]:idx=np.flatnonzero(sel&(arms==g));perm[idx]=rng.permutation(B[idx])
   dd,*_=estimate(perm,sel);ref.append(float(dd[clean].mean()))
  obs=float(d[clean].mean())
  # Residual moving-block exercise calibrates a projection statistic only.
  pre=d[:96];prex=np.arange(96);Q=np.column_stack([np.ones(96),prex]+[(prex%12==m).astype(float) for m in range(1,12)])
  residual=pre-Q@np.linalg.lstsq(Q,pre,rcond=None)[0];bs=[]
  for rep in range(4999):
   st=int(rng.integers(0,96-12+1));block=residual[st:st+12];st5=int(rng.integers(0,8));bs.append(float(block[st5:st5+5].mean()))
  pseudo_sd=float(np.std(bs,ddof=1))
  summaries.append({'specification':key,'units':int(sel.sum()),'listed_units':int((sel&(arms==1)).sum()),'nonlisted_units':int((sel&(arms==0)).sum()),'units_kept':','.join(np.array(units)[sel]),'B_common_low':lo,'B_common_high':hi,'point_common_support':lo<=hi,'candidate_Dec2018_Apr2019_contrast':obs,'holdout2017_RMSE':float(np.sqrt(np.mean(err**2))),'holdout2017_bias':float(err.mean()),'four_calendar_placebos_json':json.dumps(fake),'dose_reassignment_reference_fraction_not_pvalue':float((1+np.sum(np.abs(ref)>=abs(obs)))/5000),'conditional_projection_MDE80_not_policy_MDE':(1.959963984540054+.8416212335729143)*pseudo_sd,'inference':'descriptive_projection; failed_pre_support; nonrandom_dose; no_causal_pvalue'})
write('dynamic_projection.csv',series);write('projection_diagnostics.csv',summaries)
# Four ADRs: join a publication-linked pre2018 legal-entity subset, not a full group.
firmdose=rows(raw['historical_firms']);fd={r['unit'].replace('_group',''):r for r in firmdose if r['unit'].endswith('_group') and r['variant']=='ALL'}
cars=list(csv.DictReader((P.parent/'market/firm_event_car.csv').open(encoding='utf-8-sig')))
joined=[]
for r in cars:
 if r['firm_id'] not in fd or r['clock_version']!='primary_fixed_calendar':continue
 a=fd[r['firm_id']];n=a['known_pairs'];m=a['known_us_mass'];tot=a['pairs']
 joined.append({**r,'source_families_historical':a['source_families'],'known_pairs_historical':n,'B_historical_observed_countries':m/n,'conditional_lower':m/tot,'conditional_upper':(m+tot-n)/tot,'B_status':'public_pre2018_doc_2017_entity_subset_incomplete','interpretation':'descriptive_stock_valuation_not_RnD_allocation'})
write('four_ADR_B_CAR.csv',joined)
firm_summary=[]
for event in sorted({r['event_id'] for r in joined}):
 for window in ['[-1,+1]','[0,+1]']:
  rr=[r for r in joined if r['event_id']==event and r['window']==window];X=np.array([[1,float(r['B_historical_observed_countries'])/.1] for r in rr]);y=np.array([float(r['CAR_pct']) for r in rr]);a,b=np.linalg.lstsq(X,y,rcond=None)[0]
  firm_summary.append({'event':event,'window':window,'n':len(rr),'intercept_pct':a,'slope_pctpoints_per10pp_B':b,'no_p_value':'four_firms_convenience_sample;shared_news;B_measurement_error'})
write('four_ADR_slope_summary.csv',firm_summary)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(8.4,4.4));
for key,(B,sel,d) in specs.items():
 if key.startswith('public_multi'):ax.plot(np.arange(120),d,label=key.split('__')[1].replace('_',' '),lw=1.3)
for t in [96,99,101,103,106]:ax.axvline(t,color='#bac0c8',lw=.5)
ax.axvspan(107,111,color='#dae6f5',alpha=.5);ax.axhline(0,color='black',lw=.7);ax.set_xticks(np.arange(0,120,12),range(2010,2020));ax.set_ylabel('Listed minus nonlisted slope / 10pp B\nrelative log(1+WO families), 2017 baseline');ax.legend(fontsize=8);fig.tight_layout();fig.savefig(O/'monthly_projection.png',dpi=190);plt.close(fig)
fig,ax=plt.subplots(figsize=(7.4,4.2));rr=[r for r in joined if r['event_id']=='ANPRM_NOV16_19' and r['window']=='[0,+1]'];
for r in rr:ax.scatter(float(r['B_historical_observed_countries'])*100,float(r['CAR_pct']),color='#183d63');ax.annotate(r['firm_id'],(float(r['B_historical_observed_countries'])*100,float(r['CAR_pct'])),xytext=(4,4),textcoords='offset points')
ax.axhline(0,color='black',lw=.7);ax.set_xlabel('Observed-country US citation fraction, 2013–17 (%)');ax.set_ylabel('ANPRM market-model CAR [0,+1] (%)');fig.tight_layout();fig.savefig(O/'four_ADR_B_CAR.png',dpi=190);plt.close(fig)
receipt={'panel_shape':list(Y.shape),'panel_cells':Y.size,'positive_cells':int((Y>0).sum()),'family_memberships_sum_not_unique_families':int(Y.sum()),'public_country_support_pass_units':[r['unit'] for r in summ if r['passes_each_country_year_5']],'projection_summaries':summaries,'firm_summary':firm_summary,'scientific_scope':'Actual additional observations; no announcement-only causal identification or RnD allocation effect established.'}
(O/'results.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8',newline='')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
