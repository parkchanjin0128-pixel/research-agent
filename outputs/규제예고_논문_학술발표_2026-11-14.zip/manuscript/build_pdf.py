from pathlib import Path
import sys,re,json,html,hashlib
R=Path(__file__).resolve().parents[3];sys.path.insert(0,str(R/'work/research-python-packages'))
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak,KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_CENTER,TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import matplotlib;matplotlib.use('Agg')
from matplotlib.mathtext import math_to_image
from PIL import Image as PILImage
from pypdf import PdfReader
P=Path(__file__).parent;Q=P/'.qa';Q.mkdir(exist_ok=True);M=P/'논문.md'
pdfmetrics.registerFont(TTFont('Malgun','C:/Windows/Fonts/malgun.ttf'))
pdfmetrics.registerFont(TTFont('MalgunBold','C:/Windows/Fonts/malgunbd.ttf'))
W,H=A4;usable=W-108
base=ParagraphStyle('Body',fontName='Malgun',fontSize=10.5,leading=17,spaceAfter=8,wordWrap='CJK')
styles={'body':base,'h1':ParagraphStyle('Title',parent=base,fontName='MalgunBold',fontSize=23,leading=32,spaceBefore=4,spaceAfter=16,keepWithNext=True),'h2':ParagraphStyle('Section',parent=base,fontName='MalgunBold',fontSize=15,leading=22,spaceBefore=19,spaceAfter=10,keepWithNext=True),'h3':ParagraphStyle('Subsection',parent=base,fontName='MalgunBold',fontSize=12,leading=19,spaceBefore=12,spaceAfter=8,keepWithNext=True),'cell':ParagraphStyle('Cell',parent=base,fontSize=9,leading=14,spaceAfter=0),'caption':ParagraphStyle('Caption',parent=base,fontSize=8.7,leading=13,spaceAfter=11,textColor=colors.HexColor('#4B5563')),'ref':ParagraphStyle('Reference',parent=base,fontSize=9.3,leading=14.4,spaceAfter=7)}
def inline(s):
 s=s.replace('−','-').replace('10⁻¹⁶','10^(-16)').replace('10⁻¹²','10^(-12)')
 s=html.escape(s,quote=False)
 s=re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)',r'<link href="\2" color="#284F78">\1</link>',s)
 s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
 s=re.sub(r'\*([^*]+)\*',r'<i>\1</i>',s)
 return s
lines=M.read_text(encoding='utf-8').splitlines();story=[];i=0;equations=[];figures=[];in_refs=False
while i<len(lines):
 t=lines[i].strip()
 if not t:i+=1;continue
 if t.startswith('$$'):
  tex=t.strip('$ ').strip();tag=re.search(r'\\tag\{([^}]+)\}',tex);tex=re.sub(r'\\tag\{[^}]+\}','',tex).strip()
  ep=Q/f'equation-{len(equations)+1}.png'
  math_to_image('$'+tex+'$',str(ep),dpi=360,format='png',color='#172D46')
  im=PILImage.open(ep);ww=min(usable-14,im.width/3.5);hh=ww*im.height/im.width
  story.extend([Spacer(1,8),Image(str(ep),width=ww,height=hh),Paragraph('('+tag.group(1)+')' if tag else '',styles['caption']),Spacer(1,4)])
  equations.append({'number':tag.group(1) if tag else None,'tex':tex});i+=1;continue
 if t.startswith('|'):
  rs=[]
  while i<len(lines) and lines[i].strip().startswith('|'):
   row=[c.strip() for c in lines[i].strip().strip('|').split('|')];i+=1
   if all(re.fullmatch(r':?-+:?',c) for c in row):continue
   rs.append(row)
  nc=len(rs[0]);weights=[1]*nc
  if nc==3:weights=[1.1,1.2,1.6]
  if nc==4:weights=[1.5,1,1,1.4]
  if nc==2:weights=[1,2.5]
  tab=Table([[Paragraph(inline(c),styles['cell']) for c in r] for r in rs],colWidths=[usable*x/sum(weights) for x in weights],repeatRows=1,hAlign='LEFT')
  tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#EDF2F7')),('LINEABOVE',(0,0),(-1,0),.8,colors.HexColor('#536B85')),('LINEBELOW',(0,0),(-1,0),.7,colors.HexColor('#7E8EA0')),('LINEBELOW',(0,-1),(-1,-1),.7,colors.HexColor('#7E8EA0')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
  story.extend([Spacer(1,6),tab,Spacer(1,12)]);continue
 if t.startswith('!['):
  m=re.fullmatch(r'!\[([^]]*)\]\(([^)]+)\)',t);src=(P/m.group(2)).resolve();im=PILImage.open(src);ww=usable;hh=ww*im.height/im.width
  story.append(KeepTogether([Image(str(src),width=ww,height=hh),Paragraph(inline(m.group(1)),styles['caption'])]));figures.append(str(src));i+=1;continue
 if t.startswith('#'):
  level=len(t)-len(t.lstrip('#'));s=t[level:].strip()
  if s=='참고문헌':
   in_refs=True
   story.append(PageBreak())
  story.append(Paragraph(inline(s),styles['h1' if level==1 else 'h2' if level==2 else 'h3']));i+=1;continue
 para=[t];i+=1
 while i<len(lines) and lines[i].strip() and not lines[i].lstrip().startswith(('#','|','$$','![','- ')):
  para.append(lines[i].strip());i+=1
 s=' '.join(para)
 if s.startswith('- '):s=s[2:]
 para=Paragraph(inline(s),styles['ref' if in_refs else 'body'])
 story.append(KeepTogether([para]) if in_refs else para)
def page(c,d):
 c.saveState()
 c.setTitle('미국의 규제 예고와 중국의 기술 대응');c.setAuthor('박찬진')
 c.setFont('Malgun',8);c.setFillColor(colors.HexColor('#657384'));c.drawString(54,H-32,'미국의 규제 예고와 중국의 기술 대응')
 c.drawRightString(W-54,31,str(d.page));c.setStrokeColor(colors.HexColor('#D5DCE3'));c.setLineWidth(.5);c.line(54,H-39,W-54,H-39)
 c.restoreState()
out=P/'규제예고와_중국의_기술대응_논문.pdf'
doc=SimpleDocTemplate(str(out),pagesize=A4,leftMargin=54,rightMargin=54,topMargin=55,bottomMargin=51)
doc.build(story,onFirstPage=page,onLaterPages=page)
reader=PdfReader(out);text='\n'.join(p.extract_text() or '' for p in reader.pages)
assert len(reader.pages)>=12 and len(equations)==6 and len(figures)==4
assert '-4.03' in text or '-4.034' in text
assert '\x00' not in text,'Unsupported glyph in PDF text'
receipt={'pages':len(reader.pages),'equations':len(equations),'figures':len(figures),'characters_extracted':len(text),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(M.read_bytes()).hexdigest(),'status':'authored;visual_review_required'}
(Q/'build_receipt.json').write_text(json.dumps(receipt,indent=2),newline='')
try:
 import fitz
 f=fitz.open(out)
 for n,p in enumerate(f):p.get_pixmap(matrix=fitz.Matrix(1.25,1.25)).save(str(Q/f'page-{n+1:02}.png'))
 receipt['rendered_pages']=len(f);(Q/'build_receipt.json').write_text(json.dumps(receipt,indent=2),newline='')
except ImportError:receipt['rendering']='PyMuPDF unavailable'
print(json.dumps(receipt,indent=2))
