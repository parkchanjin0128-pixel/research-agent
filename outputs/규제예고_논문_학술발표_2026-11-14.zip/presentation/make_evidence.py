from pathlib import Path
import csv,json,numpy as np
H=Path(__file__).resolve().parent.parent;O=Path(__file__).parent
read=lambda p:list(csv.DictReader((H/p).open(encoding='utf-8-sig')))
hour=read('trump2/hourly_extended_results.csv');daily=read('trump2/market_event_summary_2025.csv');proj=read('analysis/dynamic_projection.csv')
pr=read('trump2/hourly_prices.csv');symbols=['BIDU','BABA','JD','NTES'];clocks=['09:30','10:30','11:30','12:30','13:30','14:30','15:30'];paths=[]
for s in symbols+['^GSPC']:
 rows=sorted([r for r in pr if r['symbol']==s and r['date']=='2025-10-10' and r['local_hm'] in clocks],key=lambda r:r['local_hm']);op=float(rows[0]['open']);paths.append([100*(float(r['close'])/op-1) for r in rows])
chosen=['BIDU','BABA','JD','NTES','KWEB','MCHI'];ar=[float(next(r for r in hour if r['instrument']==s)['abnormal_return_pct']) for s in chosen]
qq=[f'{str(y)[-2:]}Q{q}' for y in range(2016,2020) for q in range(1,5)];ps=[]
for name,label in [('public_multi_office_US_share__untrimmed_diagnostic','다관청 미국비중: 비절단'),('public_multi_office_US_share__common_point_range_diagnostic','다관청 미국비중: 공통 점범위')]:
 vals=[]
 for y in range(2016,2020):
  for q in range(1,5):
   rr=[float(r['theta_listed_minus_nonlisted']) for r in proj if r['specification']==name and r['month'][:4]==str(y) and ((int(r['month'][-2:])-1)//3+1)==q];vals.append(float(np.mean(rr)))
 ps.append({'name':label,'values':vals})
data={'hourly_AR':{'categories':chosen,'series':[{'name':'시장조정 초과수익률','values':ar}],'yTitle':'%','min':-6,'max':.5},'price_path':{'categories':['10:30','11:30','12:30','13:30','14:30','15:30','16:00'],'series':[{'name':'중국 ADR4 동일가중','values':np.mean(np.array(paths[:4]),axis=0).tolist()},{'name':'S&P500','values':paths[4]}],'yTitle':'09:30 시가 대비 %','min':-8,'max':3},'benchmarks':{'categories':['S&P500','SPY','MCHI','KWEB'],'series':[{'name':'ADR4 포트폴리오 AR','values':[float(next(r for r in hour if r['instrument']==s)['abnormal_return_pct']) for s in ['four_ADR_equal_weight','four_ADR_relative_SPY','four_ADR_relative_MCHI_affected_benchmark','four_ADR_relative_KWEB_affected_benchmark']]}],'min':-5,'max':3,'yTitle':'%'},'patent_dynamic':{'categories':qq,'series':ps,'yTitle':'B10%p당 상대 log 기울기','min':-2,'max':2}}
res=read('trump2/hourly_same_clock_residuals.csv');v=[float(r['same_clock_residual_pct']) for r in res if r['instrument']=='four_ADR_equal_weight'];edges=np.arange(-4.5,2.01,.5);hist,_=np.histogram(v,bins=edges);ev=np.zeros(len(hist));ev[np.searchsorted(edges,-4.034074575742603)-1]=1
assert int(hist.sum())==len(v),'histogram range must retain all reference observations'
data['residual_reference']={'categories':[f'{a:g}~{b:g}' for a,b in zip(edges[:-1],edges[1:])],'series':[{'name':'과거59일 같은 시각 잔차','values':hist.tolist()},{'name':'사건창(별도1개)','values':ev.tolist()}],'min':0,'max':int(max(hist)+3),'yTitle':'관측 수'}
data['daily_reversal']={'categories':['10/10 선행 위협','10/13 후속·완화 묶음'],'series':[{'name':'ADR4 일별 AR','values':[-4.602203600144869,2.479391310580169]}],'min':-6,'max':4,'yTitle':'%'}
old=read('market/market_event_summary.csv');data['anprm2018']={'categories':['미국 ADR4','홍콩2','상해1','선전3'],'series':[{'name':w,'values':[float(next(r for r in old if r['event_id']=='ANPRM_NOV16_19' and r['market']==m and r['window']==w)['equal_weight_mean_CAR_pct']) for m in ['US_ADR','HK','A_SHANGHAI','A_SHENZHEN']]} for w in ['[-1,+1]','[0,+1]']],'min':-3,'max':1,'yTitle':'CAR %'}
allp=[v for s in data['patent_dynamic']['series'] for v in s['values']]
data['patent_dynamic']['min']=float(np.floor(min(allp)*2)/2-.1);data['patent_dynamic']['max']=float(np.ceil(max(allp)*2)/2+.1)
(O/'chart_data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8',newline='')
print('Saved',len(data),'complete native-chart data definitions')
