import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {Presentation,PresentationFile} from 'file:///C:/Program%20Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-737-0_26.1112.737.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/@oai/artifact-tool/dist/artifact_tool.mjs';
import {slides} from './content.mjs';
const root=import.meta.dirname, build=path.join(root,'.build'),out=path.join(root,'deliverables');
const runtime='C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-737-0_26.1112.737.0_x64__3k8sg7r9htsxt/dependencies';
const skill='<USER_HOME>/.codex/plugins/cache/openai-primary-runtime/presentations/26.1112.11217/skills/presentations';
process.env.RUNTIME_NODE_MODULES=path.join(runtime,'node/node_modules');process.env.RUNTIME_NODE=path.join(runtime,'node/bin/node.exe');
await fs.mkdir(path.join(build,'previews'),{recursive:true});await fs.mkdir(out,{recursive:true});
const {applyPresentationChartFont,finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools/artifact_tool_utils.mjs')).href);
const data=JSON.parse(await fs.readFile(path.join(root,'chart_data.json'),'utf8'));
let cleaned;try{cleaned=JSON.parse(await fs.readFile(path.join(root,'notes_spaced.json'),'utf8'));}catch{}
const P=Presentation.create({slideSize:{width:1280,height:720}}),FONT='Malgun Gothic',INK='#152F4B',BLUE='#284F78',GRAY='#576474';
const chartOwners=[],tableOwners=[];
function text(s,t,x,y,w,h,size=28,bold=false,color=INK){const a=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});a.text=t;a.text.style={fontSize:size,typeface:FONT,color,bold};return a;}
function table(s,rows,i){
 const n=rows.length,m=rows[0].length,h=Math.min(450,64*n+10),widths=m===2?[400,736]:[340,360,436];
 const tb=s.tables.add({rows:n,columns:m,left:72,top:176,width:1136,height:h,columnWidths:widths,values:rows});
 tb.styleOptions={headerRow:false,bandedRows:false};tb.borders.assign({style:'solid',fill:'#D5DCE3',width:.7});
 for(let r=0;r<n;r++)for(let c=0;c<m;c++){const ce=tb.getCell(r,c);ce.fill=r===0?'#EDF2F7':'#FFFFFF';ce.text.style={fontSize:r===0?24:23,typeface:FONT,color:INK,bold:r===0};}
 tableOwners.push(i+1);
}
function chart(s,key,i){
 const d=data[key],type=['price_path','patent_dynamic'].includes(key)?'line':'bar';
 text(s,d.yTitle,76,155,1080,30,21,false,GRAY);
 const ch=s.charts.add(type,{position:{left:68,top:199,width:1142,height:340},categories:d.categories,series:d.series.map((r,j)=>({...r,smooth:false,values:r.values.map(v=>Number(v.toFixed(6))),fill:j?'#9E5862':BLUE,line:{fill:j?'#9E5862':BLUE,width:2,style:'solid'},marker:{symbol:'circle',size:5}})),lineOptions:{smooth:false},hasLegend:d.series.length>1,legend:{position:'bottom',textStyle:{fontSize:19,fill:INK}},barOptions:{direction:'column',grouping:'clustered',gapWidth:125},xAxis:{tickLabelPosition:'low',textStyle:{fontSize:key==='patent_dynamic'?17:20,fill:GRAY},line:{fill:'#A8B3C0',width:1}},yAxis:{min:d.min,max:d.max,numberFormatCode:key==='residual_reference'?'0':'0.0',textStyle:{fontSize:18,fill:GRAY},majorGridlines:{fill:'#E1E6EC',width:.6,style:'solid'}},dataLabels:{showValue:type==='bar'&&key!=='residual_reference',position:'outEnd',numberFormatCode:'0.00',textStyle:{fontSize:20,fill:INK}},chartFill:'#FFFFFF',plotAreaFill:'#FFFFFF',chartLine:{fill:'none',width:0}});
 applyPresentationChartFont(ch,{fontFamily:FONT});chartOwners.push(i+1);
}
let elapsed=0;let script='# 학술발표 대본\n\n본문32장과 질의응답용 부록8장입니다. 아래 시간은 권장 배분이며 실제 리허설을 측정한 값은 아닙니다. 수식·표의 단위를 설명하고 질문을 받는 속도에 따라 조정합니다.\n\n';
const notesRefs=`주요 원문과 재현자료\nhttps://www.presidency.ucsb.edu/documents/truth-social-posts-october-10-2025\nhttps://www.presidency.ucsb.edu/documents/truth-social-posts-october-12-2025\nhttps://www.govinfo.gov/content/pkg/FR-2018-11-19/html/2018-25221.htm\nhttps://www.nber.org/papers/w28758\nhttps://www.nber.org/papers/w32117\nhttps://www.gao.gov/products/b-337935\n논문 §2–8의 각 결과·원문 위치; analysis/와trump2/의원자료·계산표\n단위와 해석은 해당 슬라이드 및 논문 표를 따름.`;
for(let i=0;i<slides.length;i++){
 const a=slides[i],s=P.slides.add();s.background.fill='#FFFFFF';
 if(a.cover){text(s,a.title,76,146,1128,175,58,true);text(s,a.lines[0],80,376,1120,80,31,false,GRAY);text(s,a.lines[1],80,544,1120,50,27,false,GRAY);}
 else{
  text(s,a.title,72,55,1136,78,44,true);
  if(a.type==='table')table(s,a.table,i);
  else if(a.type==='chart'){chart(s,a.chart,i);a.lines.forEach((t,j)=>text(s,t,78,567+j*38,1120,37,25,false,INK));}
  else if(a.type==='equation'){
   const eq=a.equations||[];eq.forEach((t,j)=>text(s,t,102,182+j*77,1080,68,34,false,INK));
   a.lines.forEach((t,j)=>text(s,t,80,eq.length>=3?452+j*60:398+j*67,1120,60,27,false,GRAY));
  }else{
   const spacing=a.lines.length>=4?105:135;const top=a.lines.length>=4?175:188;
   a.lines.forEach((t,j)=>text(s,t,80,top+j*spacing,1120,105,a.lines.length>=4?27:29,false,INK));
  }
 }
 text(s,a.source,74,660,1080,38,15,false,GRAY);text(s,String(i+1),1178,660,48,30,18,false,GRAY);
 const notes=cleaned?.[i]??a.notes;const start=`${Math.floor(elapsed/60)}:${String(elapsed%60).padStart(2,'0')}`;
 s.speakerNotes.text=`${a.appendix?'질의응답용 부록':`본문 시작 ${start}, 권장 ${a.time}초`}\n\n${notes}\n\n자료: ${a.source}\n\n${notesRefs}`;
 script+=`## ${i+1}. ${a.title.replaceAll('\n',' ')}\n\n${a.appendix?'질의응답용 부록':`시작 ${start} · 권장 ${a.time}초`}\n\n${notes}\n\n자료: ${a.source}\n\n`;
 if(!a.appendix)elapsed+=a.time;
}
script=`권장 본문 시간: ${Math.floor(elapsed/60)}분 ${elapsed%60}초(리허설 미측정).\n\n`+script;
await fs.writeFile(path.join(root,'발표대본.md'),script,'utf8');
await fs.writeFile(path.join(root,'발표목차.md'),'# 학술발표 목차\n\n'+slides.map((a,i)=>`${i+1}. ${a.title.replaceAll('\n',' ')}${a.appendix?' (부록)':''}`).join('\n')+'\n','utf8');
await fs.writeFile(path.join(build,'slide_manifest.json'),JSON.stringify(slides.map((a,i)=>({...a,notes:cleaned?.[i]??a.notes})),null,2),'utf8');
const candidate=path.join(build,'candidate_academic.pptx');await(await PresentationFile.exportPptx(P)).save(candidate);console.log('EXPORTED',slides.length,'SLIDES, SECONDS',elapsed);
for(let i=0;i<P.slides.items.length;i++){
 const blob=await P.export({slide:P.slides.items[i],format:'png',scale:1});await fs.writeFile(path.join(build,'previews',`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await blob.arrayBuffer()));
 if((i+1)%5===0)console.log('RENDERED',i+1);
}
const result=await finalizePresentation({workspaceDir:root,candidatePath:candidate,finalPath:path.join(out,'학술발표_2026-11-14_v4.pptx'),pythonExecutable:path.join(runtime,'python/python.exe'),integrityValidatorPath:path.join(skill,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(skill,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-heading-fit',...tableOwners.flatMap(n=>['--require-native-table-slide',String(n)])],explicitTotalSlideCount:slides.length,requiredNativeChartOwnerSlides:chartOwners,requiredNativeTableOwnerSlides:tableOwners,materializeLiteralChartWorkbooks:true,fontPolicy:{basis:'design',families:[FONT]},verifyArtifactToolImport:true,receiptPath:path.join(build,'validation_academic_v4.json')});
console.log('FINAL',JSON.stringify(result));
