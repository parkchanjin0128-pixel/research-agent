from pathlib import Path
import csv,re
BASE=Path(__file__).resolve().parent
ROWS=[]
def add(firm,name,relation,asof,url,locator,note=''):
 ROWS.append(dict(firm_id=firm,entity_legal_name=name,normalized_exact_key=re.sub(r'[^A-Z0-9 ]','',name.upper()).replace('  ',' '),relationship_label=relation,ownership_asof=asof,source_url=url,source_locator=locator,producer_read_status='primary_source_read_not_independently_verified',use_rule='exact_entity_only_no_prefix_group_union',note=note))
BU='https://www.sec.gov/Archives/edgar/data/1329099/000119312518084050/d480652d20f.htm'
BA='https://www.sec.gov/Archives/edgar/data/1577552/000104746917004019/a2231121z20-f.htm'
BE='https://www.sec.gov/Archives/edgar/data/1577552/000104746917004019/a2231121zex-8_1.htm'
JD='https://www.sec.gov/Archives/edgar/data/1549802/000110465918027777/a18-5116_120f.htm'
NT='https://www.sec.gov/Archives/edgar/data/1110646/000110465918025392/a18-5396_120f.htm'
add('BIDU','Baidu, Inc.','issuer_exact','2017-12-31',BU,'Form20F cover;Note1 F-9','Cayman issuer;2017 issuer name does not establish mainland patent identity')
add('BIDU','Baidu Online Network Technology (Beijing) Co., Ltd.','2017_confirmed_sub','2017-12-31',BU,'Note1 F-9;web lines4805-4806','Wholly-owned;listed separately from VIE')
add('BIDU','Beijing Baidu Netcom Science Technology Co., Ltd.','2017_confirmed_VIE','2017-12-31',BU,'Note1 F-9;web lines4805-4806','Controlled through Baidu Online by contracts;not equity-owned by issuer')
add('BIDU','Beijing Perusal Technology Co., Ltd.','2017_confirmed_VIE','2017-12-31',BU,'Note1 F-9;web lines4805-4810')
add('BABA','Alibaba Group Holding Limited','issuer_exact','2017-03-31',BA,'Form20F cover','Cayman issuer')
for name in ['Alibaba Group Services Limited','Alibaba (China) Co., Ltd.','Alibaba (China) Technology Co., Ltd.','Taobao (China) Software Co., Ltd.','Zhejiang Tmall Technology Co., Ltd.']:
 add('BABA',name,'2017_confirmed_consolidated_entity_relation_unresolved','2017-03-31',BE,'Exhibit8.1 asofMarch31_2017','Exhibit mixes subsidiaries and consolidated entities;do not infer sub vs VIE from list alone')
for name in ['Zhejiang Taobao Network Co., Ltd.','Zhejiang Tmall Network Co., Ltd.','Hangzhou Alibaba Advertising Co., Ltd.','Alibaba Cloud Computing Ltd.']:
 add('BABA',name,'2017_confirmed_VIE','2017-03-31',BA,'Item4.C pp111-112;web lines3302,3333-3335','VIE contractual consolidation;not issuer equity ownership')
add('JD','JD.com, Inc.','issuer_exact','2017-12-31',JD,'Form20F cover;Note1 F-12','Cayman issuer')
for name in ['Beijing Jingdong Century Trade Co., Ltd.','Beijing Jingdong Shangke Information Technology Co., Ltd.','Jiangsu Jingdong Information Technology Co., Ltd.','Shanghai Shengdayuan Information Technology Co., Ltd.']:
 add('JD',name,'2017_confirmed_sub','2017-12-31',JD,'Note1 F-12;web lines6122-6142','100 percent equity;Century Trade not assumed identical to every Trading transliteration')
for name in ['Beijing Jingdong 360 Degree E-commerce Co., Ltd.','Jiangsu Yuanzhou E-commerce Co., Ltd.']:
 add('JD',name,'2017_confirmed_VIE','2017-12-31',JD,'Note1 F-12;web lines6144-6150','JD Finance deconsolidated June30_2017;do not union Finance by brand')
add('NTES','NetEase, Inc.','issuer_exact','2017-12-31',NT,'Form20F cover;Note1 F-7','Cayman issuer')
for name in ['NetEase (Hangzhou) Network Co., Ltd.','Guangzhou Boguan Telecommunication Technology Co., Ltd.','NetEase Information Technology (Beijing) Co., Ltd.']:
 add('NTES',name,'2017_confirmed_sub','2017-12-31',NT,'Note1 F-7;web lines5226-5240')
for name in ['Guangzhou NetEase Computer System Co., Ltd.','Hangzhou NetEase Leihuo Network Co., Ltd.']:
 add('NTES',name,'2017_confirmed_VIE','2017-12-31',NT,'Note1 F-7;web lines5241-5257','VIE;contractual economic link rather than issuer equity title')
add('JD','Beijing Jingdong Century Trading Co., Ltd.','unconfirmed_alias','unknown',JD,'Canonical name is Century Trade in Note1 F-12','Do not treat English transliteration variant as distinct confirmed legal entity without person_id/address corroboration')
with (BASE/'entity_map_2017.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(ROWS[0]));w.writeheader();w.writerows(ROWS)
print('rows',len(ROWS))
