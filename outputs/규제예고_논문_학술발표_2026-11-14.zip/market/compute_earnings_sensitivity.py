from pathlib import Path
import pandas as pd
BASE=Path(__file__).resolve().parent
c=pd.read_csv(BASE/'firm_event_car.csv')
c=c[(c.event_id=='ANPRM_NOV16_19')&(c.clock_version=='primary_fixed_calendar')]
e=pd.read_csv(BASE/'earnings_and_news.csv');rows=[]
for (market,window),x in c.groupby(['market','window']):
 col='ANPRM_minus1_plus1_overlap' if window=='[-1,+1]' else 'ANPRM_0_plus1_overlap'
 exclude=e.loc[e.news_id.str.startswith('EARN_') & e[col].eq('yes'),'firm_id'].tolist()
 keep=x[~x.firm_id.isin(exclude)]
 rows.append(dict(market=market,window=window,n_full=len(x),mean_full_CAR_pct=x.CAR_pct.mean(),excluded_by_verified_own_earnings='|'.join(x.loc[x.firm_id.isin(exclude),'firm_id']),n_remaining=len(keep),mean_remaining_CAR_pct=keep.CAR_pct.mean(),causal_status='NVDA_APEC_and_other_news_remain;not_clean_announcement_effect'))
pd.DataFrame(rows).to_csv(BASE/'earnings_window_sensitivity.csv',index=False)
