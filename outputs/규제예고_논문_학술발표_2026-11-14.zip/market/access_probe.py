from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import requests, json, hashlib, time

BASE=Path(__file__).resolve().parent
RAW=BASE/'raw'; RAW.mkdir(exist_ok=True)
URLS={
 'stooq_bidu':'https://stooq.com/q/d/l/?s=bidu.us&i=d&d1=20170101&d2=20191231',
 'yahoo_bidu':'https://query1.finance.yahoo.com/v8/finance/chart/BIDU?period1=1483228800&period2=1577836800&interval=1d&events=div%2Csplits&includeAdjustedClose=true',
}

def fetch(item):
 key,url=item
 stamp=datetime.now(timezone.utc).isoformat()
 try:
  r=requests.get(url,timeout=30,headers={'User-Agent':'Mozilla/5.0 (public academic data access)'})
  raw=r.content
  ext='json' if 'yahoo' in key else 'csv'
  path=RAW/(key+'.'+ext); path.write_bytes(raw)
  result={'key':key,'url':url,'retrieved_utc':stamp,'status':r.status_code,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'path':str(path.relative_to(BASE)),'content_type':r.headers.get('content-type'),'head':r.text[:180]}
  if 'yahoo' in key and r.ok:
   d=r.json()['chart']['result'][0]
   result['observations']=len(d.get('timestamp',[]))
  return result
 except Exception as e:
  return {'key':key,'url':url,'retrieved_utc':stamp,'error':repr(e)}

if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=2) as ex:
  results=list(ex.map(fetch,URLS.items()))
 (BASE/'access_probe.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
 for r in results: print(json.dumps(r,ensure_ascii=False))
