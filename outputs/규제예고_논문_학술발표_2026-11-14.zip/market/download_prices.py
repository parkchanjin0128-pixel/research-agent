from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from urllib.parse import quote
import requests,json,hashlib

BASE=Path(__file__).resolve().parent
RAW=BASE/'raw'; RAW.mkdir(exist_ok=True)
SYMBOLS=['BIDU','BABA','JD','NTES','0700.HK','0992.HK','603019.SS','000977.SZ','002230.SZ','002415.SZ','^GSPC','^HSI','000001.SS','399001.SZ']
def fetch(symbol):
 url=f'https://query1.finance.yahoo.com/v8/finance/chart/{quote(symbol,safe="")}?period1=1483228800&period2=1577836800&interval=1d&events=div%2Csplits&includeAdjustedClose=true'
 path=RAW/('yahoo_'+symbol.replace('^','INDEX_')+'.json')
 stamp=datetime.now(timezone.utc).isoformat()
 try:
  if symbol=='BIDU' and (RAW/'yahoo_bidu.json').exists():
   raw=(RAW/'yahoo_bidu.json').read_bytes();path.write_bytes(raw)
   status=200; cached=True
  else:
   r=requests.get(url,timeout=35,headers={'User-Agent':'Mozilla/5.0 (public academic data access)'})
   raw=r.content;path.write_bytes(raw); status=r.status_code; cached=False
  record={'symbol':symbol,'url':url,'retrieved_utc':stamp,'status':status,'cached_probe':cached,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'raw_path':str(path.relative_to(BASE))}
  obj=json.loads(raw); d=obj['chart']['result'][0]
  record.update(observations=len(d.get('timestamp',[])),timezone=d['meta'].get('exchangeTimezoneName'),currency=d['meta'].get('currency'),firstTradeDate=d['meta'].get('firstTradeDate'),events=list(d.get('events',{})))
  return record
 except Exception as e:
  return {'symbol':symbol,'url':url,'retrieved_utc':stamp,'error':repr(e)}
if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=4) as ex: records=list(ex.map(fetch,SYMBOLS))
 (BASE/'price_download_manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
 for r in records:print(json.dumps(r,ensure_ascii=False))
