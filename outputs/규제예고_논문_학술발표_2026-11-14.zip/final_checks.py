from pathlib import Path
import sys,json,csv,zipfile,hashlib,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'work/research-python-packages'))
from pypdf import PdfReader
from reportlab.pdfgen import canvas
from PIL import Image
H=Path(__file__).parent;P=H/'presentation';checks=[]
def check(name,value,details=None):
 assert value,(name,details)
 checks.append({'check':name,'passed':True,'details':details})
read=lambda p:list(csv.DictReader((H/p).open(encoding='utf-8-sig')))
a=read('analysis/monthly_family_counts.csv');n=[int(r['families']) for r in a]
check('patent_panel_dimensions',len(a)==10800)
check('positive_patent_cells',sum(x>0 for x in n)==4085)
check('family_membership_sum',sum(n)==32330,'Memberships, not unique global families')
check('hourly_raw_bars',len(read('trump2/hourly_prices.csv'))==8877)
check('2025_daily_rows',len(read('trump2/prices_2023_2025.csv'))==12583)
check('2018_daily_rows',len(read('market/prices_2017_2019.csv'))==10361)
hour=read('trump2/hourly_extended_results.csv')
ar=float(next(r for r in hour if r['instrument']=='four_ADR_equal_weight')['abnormal_return_pct'])
check('reported_hourly_portfolio_AR',abs(ar-(-4.034074575742603))<1e-10)
win=read('trump2/estimation_window_sensitivity.csv')
check('literal_55_candidate_day_sensitivity',abs(float(next(r for r in win if r['fit_rule']=='literal_prior60_minus5_equals55' and r['instrument']=='four_ADR_equal_weight')['abnormal_return_pct'])-(-3.922190645897837))<1e-10)
manifest=json.loads((P/'.build/slide_manifest.json').read_text(encoding='utf-8'))
check('40_slides_32_main_8_appendix',len(manifest)==40 and sum(not x.get('appendix',False) for x in manifest)==32)
check('speaker_notes_every_slide',all(len(x['notes'])>=50 for x in manifest))
v=json.loads((P/'.build/validation_academic_v4.json').read_text(encoding='utf-8'))
ppt=P/'deliverables/학술발표_2026-11-14_v4.pptx'
check('final_ppt_integrity',hashlib.sha256(ppt.read_bytes()).hexdigest()==v['finalSha256'] and v['packageIntegrity']['status']=='pass')
check('layout_and_import',v['presentationLayout']['findingCount']==0 and v['firstPartyImport']['passed'])
check('native_tables_13',v['nativeTableArithmetic']['native_table_count']==13)
check('native_charts_7',v['nativeChartValidation']['detectedChartCount']==7 and v['nativeChartValidation']['passed'])
data=json.loads((P/'chart_data.json').read_text(encoding='utf-8'));keys=['hourly_AR','price_path','residual_reference','benchmarks','daily_reversal','anprm2018','patent_dynamic'];ns={'c':'http://schemas.openxmlformats.org/drawingml/2006/chart'}
with zipfile.ZipFile(ppt) as z:
 check('ppt_zip_crc',z.testzip() is None)
 for i,key in enumerate(keys,1):
  el=ET.fromstring(z.read(f'ppt/slides/charts/chart{i}.xml'));actual=[]
  for ser in el.findall('.//c:ser',ns):
   val=ser.find('c:val',ns);actual += [float(x.text) for x in val.findall('.//c:pt/c:v',ns)]
  expected=[x for se in data[key]['series'] for x in se['values']]
  check('chart_cache_matches_source_'+key,len(actual)==len(expected) and max(abs(x-y) for x,y in zip(actual,expected))<.000001)
paper=H/'manuscript/규제예고와_중국의_기술대응_논문.pdf';pdf=PdfReader(paper);txt='\n'.join(p.extract_text() or '' for p in pdf.pages)
check('paper_15_pages',len(pdf.pages)==15)
check('paper_no_missing_glyphs',chr(0) not in txt)
check('paper_contains_results_and_literature',all(s in txt for s in ['4.03','Kang','Shen','6. 계량경제학적 설계','7. 실증 결과','참고문헌']))
check('paper_six_display_equations',len(__import__('re').findall(r'^\$\$',(H/'manuscript/논문.md').read_text(encoding='utf-8'),__import__('re').M))==6)
preview=P/'deliverables/학술발표_2026-11-14.pdf';c=canvas.Canvas(str(preview),pagesize=(960,540));c.setTitle('미국의 규제 예고와 중국의 기술 대응');c.setAuthor('박찬진')
for i in range(1,41):
 img=P/'.build/final_v4_previews'/f'slide-{i}.png';check(f'final_slide_render_{i}',img.exists());c.drawImage(str(img),0,0,width=960,height=540);c.showPage()
c.save();check('slide_pdf_40_pages',len(PdfReader(preview).pages)==40)
receipt={'performed_by':'/root (author integration checks; not independent verification)','checks':checks,'visual_review':'All 40 initial slides individually inspected; changed final charts and equations re-inspected. Final v3-to-v4 only slide18 differs and inspected. All 15 paper pages inspected; final changed pp7–15 re-inspected.','new_whole_paper_independent_acceptance':False,'native_PowerPoint_opening_tested':False,'artifacts':{p.relative_to(H).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [paper,ppt,preview]},'claim_boundary':'Arithmetic, packaging, editable chart cache, layout and author visual checks. Not a test of causal identification or journal novelty.'}
(H/'QA.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
q=H/'manuscript/.qa/build_receipt.json';r=json.loads(q.read_text());r['status']='author_visual_review_complete; scientific limitations disclosed';q.write_text(json.dumps(r,indent=2),encoding='utf-8')
print(json.dumps({'checks_passed':len(checks),'paper_pages':15,'deck_slides':40,'artifacts':receipt['artifacts']},ensure_ascii=False))
