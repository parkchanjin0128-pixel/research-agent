# IPC2017 의미에 고정한 ANPRM 열거/비지목 후보 — 2026-11-14

**24개 후보(positive12, nonlisted12)를 배분결과·B·특허건수 열람 없이 새로 만들었다.** IPC2017 원문에서 각 뿌리의 전체 하위코드를 펼쳤고, 공식 연간 RCL을 순차 적용해 2026.01까지 연결했다. 최초 후보를 만든 날짜는 오늘이며, 기존 결과를 알고 진행하는 연구의 추가 탐색이다. 사전등록·불가역 freeze 또는 원 논문의 인과식별 회복이 아니다. 독립 검증은 대기다.

## 두 라벨의 정확한 뜻

`positive`는 2018 ANPRM의 **명시된 세부기술/적층제조 범주 안에 들어가는 좁은 기술 의미의 후보**다. 예를 들어 생물모델 컴퓨터 전체 G06N3/00를 지목하지 않고 신경망3/02와 유전모델3/12 하위만 선택한다. 음성처리에서는 명시 예시인 합성·인식을 선택한다. 이는 AI 및 기계학습이라는 상위 문맥에서 열거된 기술의 텍스트 footprint다. 모든 해당 특허가 당시 emerging technology로 평가되었다거나, 실제 추가 통제를 받았거나, 그 의미가 최초로 이 문서에서 공개되었다는 판정은 아니다. 일반적인 영상분석·음성합성도 포함하므로 신종 AI만의 표본이라고 부르지 않는다.

`nonlisted`는 **정확한 IPC 기술 의미가 14개 열거범주/세부기술 자체를 나타내지 않는 전통적 성형·제거가공 후보**다. 단어가 일치하지 않는다는 이유만으로 정한 라벨이 아니다. 예를 들어 원형톱 절삭, 소성변형 압연, 인발, 직선 굽힘은 명시적 적층제조와 공정 의미가 구별된다. 통상 기계에 프로그램제어·복사장치가 있다는 사실만으로 AI 또는 로보틱스 자체를 나타내지는 않는다. 밀링기술을 가스터빈이나 극초음속 제품에 사용할 수 있다는 가능성도 그 분류 전체를 극초음속 추진기술로 만들지 않는다.

**ANPRM 비지목은 다른 정책의 무영향, 무통제, 무파급, 비교집단의 외생성 또는 개별 family의 청정성이라는 뜻이 아니다.** 실제 ANPRM의 대표목록은 exhaustive한 법적 품목목록이 아니다. 어느 쪽에도 CCL·ECCN·최종사용자·China-binding 제한 상태를 부여하지 않았다. 개별 family는 지목·비지목 기술을 함께 가질 수 있다. 그 겹침을 제거해 대조표본을 사후 정화하지 말고 수치와 원인을 먼저 공개해야 한다.

## 후보 목록

| ID | 라벨 | IPC2017 뿌리 | 좁은 의미 |
|---|---|---|---|
| P01 | positive | G06N3/02 | 신경망 모델 컴퓨터 |
| P02 | positive | G06N3/12 | 유전모델 컴퓨터 |
| P03 | positive | G06N5/00 | 지식기반 모델 컴퓨터 |
| P04 | positive | G06T7/00 | 영상 분석 |
| P05 | positive | G10L13/00 | 음성 합성 |
| P06 | positive | G10L15/00 | 음성 인식 |
| P07 | positive | B33Y10/00 | 적층제조 공정 |
| P08 | positive | B33Y30/00 | 적층제조 장치 |
| P09 | positive | B33Y40/00 | 적층제조 보조작업·설비 |
| P10 | positive | B33Y50/00 | 적층제조 데이터수집·처리 |
| P11 | positive | B33Y70/00 | 적층제조 전용 재료 |
| P12 | positive | B33Y80/00 | 적층제조 제품 |
| N01 | nonlisted | B21B1/00 | 금속 압연 |
| N02 | nonlisted | B21C1/00 | 금속 인발 |
| N03 | nonlisted | B21D5/00 | 판금 직선 굽힘 |
| N04 | nonlisted | B21D7/00 | 봉·형재·관 굽힘 |
| N05 | nonlisted | B23B1/00 | 선삭 방법 |
| N06 | nonlisted | B23C3/00 | 특정 가공물의 밀링 |
| N07 | nonlisted | B23D1/00 | 수평 직선 평삭·형삭 |
| N08 | nonlisted | B23D5/00 | 비직선 평삭·형삭 |
| N09 | nonlisted | B23D15/00 | 평행날 전단 |
| N10 | nonlisted | B23D45/00 | 원형톱 절삭 |
| N11 | nonlisted | B24B5/00 | 회전면 연삭 |
| N12 | nonlisted | B24B7/00 | 평면 연삭 |

22개는 main-group subtree, P01·P02는 보다 좁은 subgroup subtree다. 양쪽 모두 같은 XML 파서·하위 exactcode 전개·연간 RCL 경로·동일 SQL 일치규칙을 적용했다. 같은 파이프라인이 의미적 크기·분류밀도·분류시기·B 분포의 동일성을 보장하지는 않는다. IPC2017 exactcode는 P01 7개부터 P04 66개까지 다르다. 일반 기계제조 대조와 컴퓨터/음성 지목집단은 기술영역도 다르므로, B의 공통지지와 사전경로를 실제 확인하기 전에는 비교가능한 matched placebo라고 부르지 않는다.

## 사용 파일과 SQL 의미

- `groups_24.csv`: 24개 뿌리, ANPRM locator, 라벨, 전체 계층경로, 상속 scope note, 2017/2020/2026 exactcode 목록.
- `canonical_ipc2017_exact.csv`: 309개 canonical 분류코드마다 전체 계층·제목·scope note·제목의 참조범위를 보존한다. 안내 heading인 `kind=g`와 note인 `kind=n`은 실제 분류코드에 넣지 않았다.
- `ipc_aliases_2017_2026.csv`: canonical2017→각 연도 alias 3,255행. unchanged는 해당 연도 scheme에 존재하는 경우 identity, changed는 실제 RCL edge를 따른다.
- **`sql_exact_membership_union_2017_2026.csv`**: 판본 열이 없는 현행 IPC 검색용 합집합 348행. `ipc_compact`와 공백을 제거한 특허 IPC의 **완전일치**로 연결한다. 같은 group×코드는 한 행이다.
- `rcl_changed_edges.csv`: 실제 바뀐 48개 경로와 RCL XML·프로젝트·default-reclassification 값을 보존한다. default=Y만 남기지 않았다.
- `crosswalk_full.json`: 기계가 읽을 수 있는 모든 분류·scope 원문·연결·생산점검.
- `analysis_unit_map.csv`: P01/P02는 neural/genetic union, P07–P12는 AM union으로 묶는 보조표. 원24행을 보존하고 같은 단위 안의 family는 union한다.
- `source_manifest.json`, `wipo_2021_2026_download_manifest.json`: 원문 해시·신규 다운로드 HTTP 응답·ZIP member·해시.

예를 들어 `G06N3/02`라는 문자열의 접두어 검색은 그 아래 `/04`, `/06`, `/08`을 회수하지 못한다. main-group `/00` 문자열도 같은 의미의 하위코드 접두어가 아니다. 이 표는 XML의 실제 계층을 전개한 exactcode 표이며 SQL `LIKE 'G06N3/02%'` 또는 `/00` 제거 후 임의 prefix로 대체하면 안 된다. IPC 공백만 제거해 `G06N3/02`처럼 비교한다. 코드를 숫자로 변환하거나 소수점처럼 해석하지 않는다. 14자리 WIPO symbol도 별도 제공하므로 필요하면 그 형식으로 정규화한 뒤 완전일치할 수 있다.

같은 family가 여러 IPC·문헌·연도 alias를 가질 수 있다. 각 기술 단위×국가×시점의 family union을 먼저 만들고, B의 분자·분모와 결과의 소속정의에 동일한 표를 쓴다. family의 여러 국가주소가 있는 경우는 이 분류표가 해결하지 않는다. 원 DB의 분류판본/시점·invention/additional value·first position을 확인해야 한다. 현재와 과거 코드의 합집합은 문헌내용을 자동 검증하거나 당시 분류자의 정보집합을 복구하는 방법이 아니다.

## 분류 관행과 집계단위의 한계

**B33Y는 다른 분류에 추가되는 의무적 보충분류다.** IPC2017 subclass note는 적층제조의 공정·재료와 무관한 포괄성, 다른 분류와 결합한 검색 목적, 보충분류 의무, 특허에 처음 제시되는 분류가 아니라는 점, 여러 aspect의 다중분류를 명시한다. 따라서 six aspect를 독립적인 여섯 실험으로 읽거나 firstIPC 표본에서 사라지는 것을 실질적인 기술쇠퇴로 읽으면 안 된다. 첫 분류와 모든 분류의 비교에서는 이 비대칭을 따로 보여야 한다. `crosswalk_full.json`에 해당 note의 전체 원문 XML이 있다.

기술별 exactcode 집합은 서로 겹치지 않지만, family 수준 겹침과 기술별 충격의 상관은 미측정이다. 24개 후보는 독립24단위를 뜻하지 않는다. AM 여섯은 단일 cluster/union을 기본 보조단위로 표시했고, 신경망·유전모델의 같은 컴퓨터 상위문맥도 합집합표로 제공했다. root가 실제 family 겹침·분류위치·사전지원으로 진단할 항목이며, 생산자가 유리한 결과에 따라 단위를 선택하지 않았다.

## 2026 연결과 넓은 prefix 대안의 실제 점검

공식 WIPO 2021–2026 scheme/RCL ZIP 12개를 실제 HTTP200으로 회수했다. 2017–2026 전체 연간 scheme10개·RCL9개를 적용했다. 선택집단의 RCL target에 해당집단의 직전 집합 밖에서 들어오는 source는 발견되지 않았고, 판본 내 그룹 간 exactcode 중첩도 없었다. 이것은 RCL의 공식 구조점검 결과이며 개별 특허의 의미·누락 없는 재분류를 독립 검증한 결과는 아니다. 2027 이후는 추적하지 않았다.

`fallback_scope_checks.json`의 실제 차집합은 넓은 prefix가 동일정의가 아님을 보여준다.

- B33Y subclass 전체는 현재 P07–P12 union에 없는 잔여 `B33Y99/00`를 추가한다(모든 확인판본). 따라서 subclass prefix는 현재6그룹 union의 완전동등 대체가 아니다. 99/00를 nonlisted로 판정한 것은 아니다.
- G06N3 전체는 2017의 일반 생물모델 `3/00`, 2023 이후의 `3/004`, `3/006`, `3/008`도 포함한다. 따라서 P01/P02의 exact union과 동등하지 않다. 추가범위는 인공생명, 생명체/집단 시뮬레이션·PSO, 생명을 모방하는 지능로봇 등이며 신경망·유전계산과 같은 의미라고 일괄 확정하지 않았다. 이들 중 일부가 ANPRM의 다른 열거기술과 겹칠 수 있으므로 nonlisted로 판정한 것도 아니다.

정의 보존 병합은 기존 exactcode의 union으로 수행한다. 넓은 prefix는 별도의 확장정의로 명시해야 하며 결과 열람 뒤 채택해 사전고정이라고 부를 수 없다.

## 결과와 독립적인 제외 판단

G06F/G06N/G06T subclass 전체, 일반 반도체, 일반 생명공학, 일반 첨단재료 상위는 서로 다른 열거/비열거 의미를 섞어 제외했다. G06F15/18과 G06N99/00에서 후속 G06N20/00으로 연결되는 기존 many-to-many 문제를 단일 ML 전용 코드로 덮지 않았다. G06F17/20 전체는 서식·편집과 NLP를 섞으므로 채택하지 않았다. 더 좁은17/28 등은 별도 positive 후보가 될 수 있지만 현재24행은 ANPRM 전체기술의 전수목록이 아니다. 음성코덱 G10L19/00, 화자식별 G10L17/00의 비인간음성 하위 등은 이번 높은 명확성 우선목록에 넣지 않았다. 일반 로봇·물류·PNT·양자·극초음속·기능성섬유를 부정확한 넓은 IPC로 채워 숫자를 늘리지 않았다. 포함되지 않은 코드를 자동으로 nonlisted로 분류하지 않는다.

## 생산점검과 원문

생산자 검사는 24그룹, canonical309코드, union348행, changed48edges, 판본별 code overlap0, RCL external incoming0, 분류결과/B/특허건수 파일 열람0이다. 이것은 독립 verifier의 판정이 아니다. 원 causal paper reject와 SCI-01 등 미해결, 기존 Gate·PCX 이력은 그대로다. 이 표는 missing listed−nonlisted 분석을 실행할 입력 하나를 새로 제공할 뿐이다.

- [ANPRM 원문, 83 FR 58201–58202](https://www.govinfo.gov/content/pkg/FR-2018-11-19/html/2018-25221.htm): Representative Technology Categories (2)(i),(ii),(iv),(v),(vi),(9).
- [WIPO IPC2017 scheme](https://www.wipo.int/classifications/data/ipc/ITSupport_and_download_area/20170101/MasterFiles/ipc_scheme_20170101.zip): `symbol` 및 `kind`로 각 exact locator를 찾는다.
- [WIPO IPC2026 scheme](https://www.wipo.int/classifications/data/ipc/ITSupport_and_download_area/20260101/MasterFiles/ipc_scheme_20260101.zip), [2025→2026 RCL](https://www.wipo.int/classifications/data/ipc/ITSupport_and_download_area/20260101/MasterFiles/ipc_concordancelist_20260101.zip). 각 중간 연도의 실제 URL·HTTP 응답은 다운로드 manifest에 있다.
