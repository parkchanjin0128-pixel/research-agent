"""결과/B를 읽지 않는 IPC2017 의미기반 탐색용 분류표 생산기."""
from pathlib import Path
from collections import defaultdict, Counter
import csv, hashlib, json, re
from lxml import etree

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[2]
SRC = BASE / 'outputs/final_research/ip_security/sources'
YEARS = [str(y)+'0101' for y in range(2017,2027)]
NSURI = 'http://www.wipo.int/classifications/ipc/masterfiles'
TAG = '{' + NSURI + '}ipcEntry'
NS = {'i': NSURI}

def is_classifiable(n):
    return n.get('kind') == 'm' or n.get('kind', '').isdigit()

def display(s):
    if len(s) != 14:
        return s
    sub = (s[8:].rstrip('0') or '0').ljust(2, '0')
    return f'{s[:4]}{int(s[4:8])}/{sub}'

def render(n):
    # sref/mref elements carry their text in attributes, not itertext().
    if etree.QName(n).localname in ('sref', 'mref'):
        a = display(n.get('ref', ''))
        b = display(n.get('endRef', ''))
        return '[' + a + ('–' + b if b else '') + ']'
    out = n.text or ''
    for c in n:
        out += render(c) + (c.tail or '')
    return re.sub(r'\s+', ' ', out).strip()

def title(n):
    own = n.find('i:textBody/i:title', NS)
    if own is None:
        return ''
    # References are retained separately, to avoid treating excluded examples as title scope.
    return '; '.join(render(x) for x in own.findall('i:titlePart/i:text', NS))

def own_body(n):
    b = n.find('i:textBody', NS)
    return etree.tostring(b, encoding='unicode', with_tail=False) if b is not None else ''

schemes = {}
trees = {}
def source_path(filename):
    p=SRC/filename
    return p if p.exists() else HERE/'sources'/filename

for y in YEARS:
    tree = etree.parse(str(source_path(f'ipc_scheme_{y}_EN_ipc_scheme_{y}.xml')))
    trees[y] = tree
    schemes[y] = {n.get('symbol'): n for n in tree.iter(TAG)
                  if is_classifiable(n) or n.get('kind') in ('s', 'c', 'u')}

rcls = {}
for y in YEARS[1:]:
    tree = etree.parse(str(source_path(f'ipc_concordancelist_{y}_ipc_concordancelist_{y}.xml')))
    rcls[y] = {n.get('from-symbol'): n for n in tree.getroot()}

# No outcome, B, patent count, citation, or funding file is opened by this producer.
SPEC = [
 ('P01','positive','신경망 컴퓨터','G06N0003020000','ai_computing','(2)(i)','Neural networks and deep learning','생물모델 상위3/00 전체 대신 신경망3/02 하위만 포함한다.'),
 ('P02','positive','유전모델 컴퓨팅','G06N0003120000','ai_computing','(2)(ii)','Evolution and genetic computation','생물모델 상위3/00 전체 대신 genetic model computing의 명시 하위만 포함한다.'),
 ('P03','positive','지식기반 컴퓨터','G06N0005000000','ai_computing','(2)(v)','Expert systems','지식표현·추론을 포함한 knowledge-based computer models를 expert-system 계열에 대응한다.'),
 ('P04','positive','영상 분석','G06T0007000000','computer_vision','(2)(iv)','Computer vision','영상분할·움직임·정합·깊이·기하 속성 분석의 범위를 computer vision의 명시 범주에 대응한다.'),
 ('P05','positive','음성 합성','G10L0013000000','speech','(2)(vi)','Speech and audio processing','명시 예시 speech production에 해당하는 음성합성·text-to-speech만 포함한다.'),
 ('P06','positive','음성 인식','G10L0015000000','speech','(2)(vi)','Speech and audio processing','명시 예시 speech recognition의 main-group과 하위를 포함한다.'),
 ('P07','positive','적층제조 공정','B33Y0010000000','additive_manufacturing','(9)','Additive manufacturing','B33Y subclass 정의를 상속하는 적층제조 공정.'),
 ('P08','positive','적층제조 장치','B33Y0030000000','additive_manufacturing','(9)','Additive manufacturing','B33Y subclass 정의를 상속하는 적층제조 장치·부속품.'),
 ('P09','positive','적층제조 보조작업·설비','B33Y0040000000','additive_manufacturing','(9)','Additive manufacturing','material handling 일반이 아니라 B33Y 적층제조 문맥의 보조작업·설비.'),
 ('P10','positive','적층제조 데이터 처리','B33Y0050000000','additive_manufacturing','(9)','Additive manufacturing','적층제조를 위한 데이터수집·처리 및 공정제어.'),
 ('P11','positive','적층제조 전용 재료','B33Y0070000000','additive_manufacturing','(9)','Additive manufacturing','재료 일반이 아니라 specially adapted for additive manufacturing인 재료.'),
 ('P12','positive','적층제조 제품','B33Y0080000000','additive_manufacturing','(9)','Additive manufacturing','제품 용도 일반이 아니라 적층제조로 만들어진 제품이라는 명시 범위.'),
 ('N01','nonlisted','금속 압연','B21B0001000000','conventional_forming','','','소성변형에 의한 금속 압연의 공정·압연기 범위다. 적층제조·로보틱스·hypersonic propulsion 자체를 뜻하지 않는다.'),
 ('N02','nonlisted','금속 인발','B21C0001000000','conventional_forming','','','인발에 의한 판·선·봉·관의 제조와 기계 범위다. 나열된 emerging technology가 아닌 전통적 성형공정이다.'),
 ('N03','nonlisted','판금 직선 굽힘','B21D0005000000','conventional_forming','','','판금의 직선 굽힘 범위다. 재료 종류나 첨단 최종용도를 일반화하지 않는다.'),
 ('N04','nonlisted','봉·형재·관 굽힘','B21D0007000000','conventional_forming','','','봉·형재·관을 굽히는 성형공정이다. 프로그램제어 하위가 있어도 이것만으로 AI·robotics를 의미하지 않는다.'),
 ('N05','nonlisted','선삭 방법','B23B0001000000','conventional_cutting','','','선반을 요하는 선삭/가공 방법과 보조설비의 사용 범위다. 제거가공은 적층제조와 구별된다.'),
 ('N06','nonlisted','특수가공물 밀링','B23C0003000000','conventional_cutting','','','특정 가공물의 밀링과 특수밀링 범위다. turbine blade 용도의 하위가 hypersonic 전용을 뜻하지 않으며 해당 최종용도 무영향을 주장하지 않는다.'),
 ('N07','nonlisted','수평 직선 평삭·형삭','B23D0001000000','conventional_cutting','','','공구와 가공물의 수평 직선 상대운동에 의한 평삭·형삭 기계 범위다.'),
 ('N08','nonlisted','비직선 평삭·형삭','B23D0005000000','conventional_cutting','','','직선운동 이외의 평삭·형삭 제거가공 기계 범위다. copying device는 AI planning과 동일하지 않다.'),
 ('N09','nonlisted','평행날 전단','B23D0015000000','conventional_cutting','','','서로 평행하게 움직이는 날에 의한 전단기계·장치 범위다.'),
 ('N10','nonlisted','원형톱 절삭','B23D0045000000','conventional_cutting','','','원형톱날·마찰톱 원판을 쓰는 절삭기계·장치 범위다. adaptive/advanced materials 일반을 수용하는 분류가 아니다.'),
 ('N11','nonlisted','회전면 연삭','B24B0005000000','conventional_grinding','','','회전면을 연삭하는 장치와 부속품 범위다. 첨단 최종용도의 부재를 판정한 것이 아니다.'),
 ('N12','nonlisted','평면 연삭','B24B0007000000','conventional_grinding','','','평면 연삭·연마 장치와 부속품 범위다. biomaterials나 기능성섬유를 포괄하는 재료 상위분류를 채택한 것이 아니다.'),
]

def path_nodes(n):
    return [x for x in reversed(list(n.iterancestors()))
            if x.tag == TAG and (is_classifiable(x) or x.get('kind') in ('s','c','u'))] + [n]

def applies(note, symbol, ancestor_symbol):
    a = note.get('symbol','')
    b = note.get('endSymbol','')
    return (not a or a == ancestor_symbol or a == symbol or
            (b and len(a) == len(symbol) and a <= symbol <= b))

def notes_for(n):
    notes, seen = [], set()
    for anc in path_nodes(n):
        for note in anc.findall('i:ipcEntry', NS):
            if note.get('kind') not in ('n','g'):
                continue
            if not applies(note, n.get('symbol'), anc.get('symbol')):
                continue
            xml = etree.tostring(note, encoding='unicode', with_tail=False)
            if xml in seen:
                continue
            seen.add(xml)
            notes.append({'at_ancestor':anc.get('symbol'),'kind':note.get('kind'),
                          'anchor':note.get('symbol'),'end_symbol':note.get('endSymbol',''),
                          'text_with_refs':render(note),'xml':xml})
    # Follow referenced scope-note anchors (e.g. B24B -> B23F notes).
    refs = set()
    for note in notes[:]:
        el = etree.fromstring(note['xml'].encode())
        refs.update(x.get('ref') for x in el.iter() if x.get('ref'))
    for ref in sorted(refs):
        target = schemes['20170101'].get(ref)
        if target is None:
            continue
        for note in target.findall('i:ipcEntry[@kind="n"]',NS):
            if note.get('symbol') != ref:
                continue
            xml = etree.tostring(note, encoding='unicode',with_tail=False)
            if xml in seen:
                continue
            seen.add(xml)
            notes.append({'at_ancestor':ref,'kind':'referenced_scope_note',
                          'anchor':note.get('symbol'),'end_symbol':note.get('endSymbol',''),
                          'text_with_refs':render(note),'xml':xml})
    return notes

groups=[]; canonical_rows=[]; alias_rows=[]; edge_rows=[]; code_detail=[]
for gid,label,name,symbol,block,locator,policy,rationale in SPEC:
    n=schemes['20170101'][symbol]
    members=[x for x in n.iter(TAG) if is_classifiable(x)]
    assert len(members) == len({x.get('symbol') for x in members})
    gp={'group_id':gid,'label':label,'name_ko':name,'domain_block':block,
        'root_symbol_14':symbol,'root_compact':display(symbol),'root_kind':n.get('kind'),
        'precision':'main_group_subtree' if n.get('kind')=='m' else 'subgroup_subtree',
        'anprm_locator':locator,'anprm_subtechnology':policy,
        'scope_rationale_ko':rationale,'canonical_2017_code_count':len(members),
        'is_supplementary_classification':symbol.startswith('B33Y'),
        'first_position_expected':False if symbol.startswith('B33Y') else None,
        'family_crosshit_rule':'retain_and_report; no outcome-dependent exclusion',
        'semantic_confidence':'high_candidate_producer_judgment_not_independently_verified',
        'legal_control_status':'not_assessed',
        'path':[{'symbol':x.get('symbol'),'display':display(x.get('symbol')),'kind':x.get('kind'),
                 'title':title(x),'text_body_xml':own_body(x)} for x in path_nodes(n)],
        'inherited_and_own_scope_notes':notes_for(n),
        'canonical_2017_exact_codes':[display(x.get('symbol')) for x in members],
        'aliases_by_version':{}}
    groups.append(gp)
    for mem in members:
        c=mem.get('symbol')
        path=path_nodes(mem)
        row={'group_id':gid,'label':label,'domain_block':block,'canonical_version':'20170101',
             'canonical_symbol_14':c,'ipc_compact':display(c),'kind':mem.get('kind'),
             'title':title(mem),'path_symbols':' > '.join(x.get('symbol') for x in path),
             'path_titles':' > '.join(title(x) for x in path),
             'scope_notes_json':json.dumps(notes_for(mem),ensure_ascii=False),
             'title_references_json':json.dumps([{'text':render(x),'xml':etree.tostring(x,encoding='unicode',with_tail=False)}
                                                for x in mem.findall('i:textBody/i:title/i:titlePart/i:entryReference',NS)],ensure_ascii=False)}
        canonical_rows.append(row)
        code_detail.append({**row,'text_body_xml':own_body(mem)})
        current={c}
        for y in YEARS:
            if y != YEARS[0]:
                outgoing=set()
                for src in current:
                    rc=rcls[y].get(src)
                    if rc is None:
                        assert src in schemes[y],(gid,y,src,'unexplained disappearance')
                        outgoing.add(src)
                    else:
                        for dest in rc:
                            to=dest.get('to-symbol')
                            assert to in schemes[y],(gid,y,to,'RCL target absent')
                            outgoing.add(to)
                            edge_rows.append({'group_id':gid,'canonical_symbol_14':c,
                                'from_version':str(int(y[:4])-1)+'0101','to_version':y,
                                'from_symbol_14':src,'from_compact':display(src),
                                'to_symbol_14':to,'to_compact':display(to),
                                'from_modification':rc.get('modification'),
                                'to_modification':dest.get('modification'),
                                'default_reclassification':dest.get('default-reclassification'),
                                'revision_project':rc.get('revision-project'),
                                'rcl_xml':etree.tostring(rc,encoding='unicode',with_tail=False)})
                current=outgoing
            for ali in sorted(current):
                alias_rows.append({'group_id':gid,'label':label,'domain_block':block,
                    'canonical_version':'20170101','canonical_symbol_14':c,
                    'canonical_compact':display(c),'alias_version':y,'alias_symbol_14':ali,
                    'ipc_compact':display(ali),'match_semantics':'exact_code_equality',
                    'prefix_match_permitted':False,'alias_title':title(schemes[y][ali])})
    for y in YEARS:
        gp['aliases_by_version'][y]=sorted({r['ipc_compact'] for r in alias_rows if r['group_id']==gid and r['alias_version']==y})

def csv_write(name,rows):
    with (HERE/name).open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

flat_groups=[]
for g in groups:
    row={k:v for k,v in g.items() if k not in ('path','inherited_and_own_scope_notes','canonical_2017_exact_codes','aliases_by_version')}
    row.update(path_symbols=' > '.join(x['display'] for x in g['path']),
               path_titles=' > '.join(x['title'] for x in g['path']),
               inherited_scope_notes_json=json.dumps(g['inherited_and_own_scope_notes'],ensure_ascii=False),
               canonical_2017_exact_codes=';'.join(g['canonical_2017_exact_codes']),
               aliases_2020_exact_codes=';'.join(g['aliases_by_version']['20200101']),
               aliases_2026_exact_codes=';'.join(g['aliases_by_version']['20260101']))
    flat_groups.append(row)
csv_write('groups_24.csv',flat_groups)
csv_write('canonical_ipc2017_exact.csv',canonical_rows)
csv_write('ipc_aliases_2017_2026.csv',alias_rows)
csv_write('rcl_changed_edges.csv',edge_rows)

# SQL mapping without ambiguous version multiplicity: UNION all codes observed in 2017..2020.
union_rows={}
for r in alias_rows:
    key=(r['group_id'],r['ipc_compact'])
    union_rows.setdefault(key,{'group_id':r['group_id'],'label':r['label'],
                              'domain_block':r['domain_block'],'ipc_compact':r['ipc_compact'],
                              'alias_symbol_14':r['alias_symbol_14'],'versions':[]})['versions'].append(r['alias_version'])
union_rows=[{**r,'versions':';'.join(sorted(set(r['versions'])))} for r in union_rows.values()]
csv_write('sql_exact_membership_union_2017_2026.csv',union_rows)

# Coarsening map preserves the original rows. It is a pre-outcome construction aid,
# not an assertion that the resulting units are statistically independent.
analysis_map=[]
for g in groups:
    if g['group_id'] in ('P01','P02'):
        unit='P_NEURAL_GENETIC_UNION'
    elif g['domain_block']=='additive_manufacturing':
        unit='P_ADDITIVE_UNION'
    else:
        unit=g['group_id']
    analysis_map.append({'group_id':g['group_id'],'label':g['label'],
                         'analysis_unit_merged_ai_am':unit,
                         'domain_block':g['domain_block'],
                         'unit_rule':'family union within unit; never sum duplicate families'})
csv_write('analysis_unit_map.csv',analysis_map)

fallback_checks=[]
for y in YEARS:
    am_selected=set().union(*(set(g['aliases_by_version'][y]) for g in groups if g['domain_block']=='additive_manufacturing'))
    am_all={display(k) for k,n in schemes[y].items() if is_classifiable(n) and k.startswith('B33Y')}
    ng_selected=set().union(*(set(g['aliases_by_version'][y]) for g in groups if g['group_id'] in ('P01','P02')))
    biological=schemes[y]['G06N0003000000']
    ng_all={display(n.get('symbol')) for n in biological.iter(TAG) if is_classifiable(n)}
    fallback_checks.append({'version':y,'B33Y_subclass_equals_selected_union':am_all==am_selected,
                            'B33Y_missing_from_union':sorted(am_all-am_selected),
                            'G06N3_whole_subtree_equals_neural_genetic_union':ng_all==ng_selected,
                            'G06N3_extra_beyond_selected_union':sorted(ng_all-ng_selected)})
(HERE/'fallback_scope_checks.json').write_text(json.dumps(fallback_checks,ensure_ascii=False,indent=2),encoding='utf-8')

# Check within-2017 and within-2020 code-set disjointness. This does NOT imply family disjointness.
overlaps=[]
for y in YEARS:
    bycode=defaultdict(set)
    for r in alias_rows:
        if r['alias_version']==y:
            bycode[r['ipc_compact']].add(r['group_id'])
    overlaps.extend({'version':y,'code':c,'groups':sorted(gs)} for c,gs in bycode.items() if len(gs)>1)

# An alias target with an RCL incoming source outside this group's previous closure is flagged.
external_incoming=[]
for g in groups:
    for i,y in enumerate(YEARS[1:],1):
        previous=set(g['aliases_by_version'][YEARS[i-1]])
        current=set(g['aliases_by_version'][y])
        for src,rc in rcls[y].items():
            for dest in rc:
                if display(dest.get('to-symbol')) in current and display(src) not in previous:
                    external_incoming.append({'group_id':g['group_id'],'to_version':y,
                                               'outside_source':display(src),'target':display(dest.get('to-symbol'))})

audit={'groups':len(groups),'label_counts':dict(Counter(g['label'] for g in groups)),
       'canonical_rows':len(canonical_rows),'versioned_alias_rows':len(alias_rows),
       'sql_union_memberships':len(union_rows),'changed_rcl_edges':len(edge_rows),
       'within_version_code_overlaps':overlaps,'external_rcl_incoming':external_incoming,
       'outcome_files_read':0,'B_files_read':0,'patent_count_files_read':0,
       'independent_verification':'pending; producer checks are not independent verification',
       'revision_closure_through':'20260101',
       'freeze':'none; exploratory current-user-directed construction, not preregistration'}
assert len(groups)==24 and not overlaps

payload={'status':'exploratory_producer_candidates_pending_independent_verification',
         'date':'2026-11-14','meaning_version':'20170101','rcl_closure_through':'20260101',
         'classification_basis':'ANPRM explicit technology footprint; not legal treatment or CCL status',
         'groups':groups,'canonical_code_detail':code_detail,'audit':audit}
(HERE/'crosswalk_full.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
(HERE/'producer_checks.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')

source_files=[SRC/'anprm2018.html.txt']+[source_path(f'ipc_scheme_{y}_EN_ipc_scheme_{y}.xml') for y in YEARS]+[source_path(f'ipc_concordancelist_{y}_ipc_concordancelist_{y}.xml') for y in YEARS[1:]]
manifest=[{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in source_files]
(HERE/'source_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(audit,ensure_ascii=False,indent=2))
