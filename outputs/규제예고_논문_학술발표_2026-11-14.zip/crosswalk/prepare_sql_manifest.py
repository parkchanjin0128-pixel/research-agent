from pathlib import Path
from collections import defaultdict
import csv,hashlib,json

HERE=Path(__file__).resolve().parent
rows=list(csv.DictReader((HERE/'sql_exact_membership_union_2017_2026.csv').open(encoding='utf-8-sig')))
groups=defaultdict(list)
for r in rows:
    groups[(r['group_id'],r['label'],r['domain_block'])].append(r['ipc_compact'])
structs=[]
for (gid,label,block),codes in groups.items():
    structs.append("  STRUCT('"+gid+"' AS group_id, '"+label+"' AS label, '"+block+"' AS domain_block, '"+','.join(codes)+"' AS exact_codes)")
sql='''-- BigQuery Standard SQL CTE. WITH 뒤 또는 기존 CTE와 쉼표로 연결한다.
-- 실제 IPC 열에서 공백을 제거한 값과 ipc_compact를 완전일치 JOIN한다.
-- REGEXP_REPLACE(UPPER(actual_ipc_column), r'\\s+', '') = technology_map.ipc_compact
-- 2017~2026 exact alias UNION이다. 임의 prefix로 바꾸지 않는다.
technology_map AS (
 SELECT t.group_id, t.label, t.domain_block, ipc_compact
 FROM UNNEST([
'''+',\n'.join(structs)+'''
 ]) AS t
 CROSS JOIN UNNEST(SPLIT(t.exact_codes, ',')) AS ipc_compact
)
'''
(HERE/'mapping_bigquery_cte.sql').write_text(sql,encoding='utf-8')
manifest=[]
for p in sorted(HERE.iterdir()):
    if p.is_file() and p.name!='artifact_manifest.json' and p.suffix in ('.csv','.json','.md','.sql','.py'):
        manifest.append({'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(HERE/'artifact_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('SQL mapping rows',len(rows),'groups',len(groups),'manifest files',len(manifest))
