from pathlib import Path
import json,hashlib,zipfile,base64,gzip
R=Path(__file__).resolve().parents[2];H=Path(__file__).parent
selected=[]
for directory in ['analysis','patstat','market','trump2','verification']:
 for p in (H/directory).glob('*'):
  if p.is_file() and p.suffix in {'.md','.json','.csv','.sql','.py','.bin','.b64','.png'}:
   selected.append(p)
for sub in ['trump2/raw','trump2/hourly_raw','market/raw']:
 selected += [p for p in (H/sub).glob('*.json') if p.is_file()]
for name in ['analysis_unit_map.csv','sql_exact_membership_union_2017_2026.csv','mapping_bigquery_cte.sql','fallback_scope_checks.json','source_manifest.json','README_ko.md','build_crosswalk.py','prepare_sql_manifest.py','producer_checks.json']:
 selected.append(H/'crosswalk'/name)
for name in ['README.md','final_checks.py','prepare_release_bundle.py','protocol.md','operations.json','checkpoint_status.md','STATUS.json','presentation/발표질의응답.md','presentation/발표대본.md','presentation/발표목차.md','presentation/content.mjs','presentation/notes_spaced.json','presentation/chart_data.json','presentation/make_evidence.py','presentation/build_academic.mjs','manuscript/논문.md','manuscript/build_pdf.py','manuscript/규제예고와_중국의_기술대응_논문.pdf','presentation/deliverables/학술발표_2026-11-14_v4.pptx','presentation/deliverables/학술발표_2026-11-14.pdf','QA.json']:
 p=H/name
 if p.exists():selected.append(p)
selected=sorted(set(selected));rows=[]
def publish_bytes(p):
 b=p.read_bytes()
 if p.suffix in {'.py','.md','.mjs','.json','.csv','.sql'}:
  s=b.decode('utf-8-sig')
  for old,new in [(str(R),'<WORKSPACE>'),(R.as_posix(),'<WORKSPACE>'),('C:\\\\Users\\\\parkc','<USER_HOME>'),('<USER_HOME>','<USER_HOME>'),('<USER_HOME>','<USER_HOME>')]:s=s.replace(old,new)
  b=s.encode('utf-8')
 return b
archive=R/'outputs/규제예고_논문_학술발표_2026-11-14.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in selected:
  b=publish_bytes(p);n=p.relative_to(H).as_posix()
  z.writestr(n,b);rows.append({'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'local_original_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 manifest={'files':rows,'archive':archive.name,'claim':'Working paper; author arithmetic checks and narrow independent verifications; no full new-paper independent acceptance'}
 z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
receipt={'path':archive.relative_to(R).as_posix(),'files':len(selected),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(H/'release_bundle_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
# A compact remote snapshot carries all selected results. Source papers and downloaded HTML/PDFs are excluded.
remote=[]
for p in selected:
 if p.suffix in {'.pdf','.pptx'} or p.name in {'README.md','STATUS.json','논문.md','발표대본.md','발표목차.md','발표질의응답.md','QA.json'} or (p.parent.name=='verification' and p.suffix=='.md') or (p.parent.name=='analysis' and p.suffix=='.png'):
  b=publish_bytes(p);remote.append({'path':p.relative_to(R).as_posix(),'content':base64.b64encode(b).decode(),'encoding':'base64'})
b=archive.read_bytes();remote.append({'path':archive.relative_to(R).as_posix(),'content':base64.b64encode(b).decode(),'encoding':'base64'})
(H/'.release_payload.json').write_text(json.dumps(remote,separators=(',',':')),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
