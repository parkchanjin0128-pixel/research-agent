"""Update independent audit with newly arrived production/independent returns."""
from pathlib import Path
import json, hashlib, math, base64, zlib
V=Path(__file__).parent; R=V.parent; P=R/'patstat'
sha=lambda b:hashlib.sha256(b).hexdigest()
def rows(d): return [dict(zip(d['columns'],r)) for r in d['rows']]
def close(a,b):
 if isinstance(a,(float,int)) and isinstance(b,(float,int)):return math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-9)
 return a==b
def compare(a,b,keys,fields):
 a={tuple(r[k] for k in keys):r for r in a}; b={tuple(r[k] for k in keys):r for r in b}
 errs=[]
 for k in sorted(set(a)|set(b)):
  if k not in a or k not in b:errs.append({'key':k,'missing':'a' if k not in a else 'b'});continue
  for f in fields:
   if not close(a[k][f],b[k][f]):errs.append({'key':k,'field':f,'a':a[k][f],'b':b[k][f]})
 return {'equal':not errs,'a_rows':len(a),'b_rows':len(b),'differences':errs}
def strvalues(x):
 if isinstance(x,str):yield x
 if isinstance(x,dict):
  for v in x.values():yield from strvalues(v)
 if isinstance(x,list):
  for v in x:yield from strvalues(v)
out=json.loads((V/'patstat_nov14.json').read_text(encoding='utf-8'))
md=(V/'patstat_nov14.md').read_text(encoding='utf-8').split('\n<!-- NEW_RETURNS -->')[0]
lines=['','<!-- NEW_RETURNS -->','','## 추가 회수자료 검증','']
hf=P/'historical_source_and_ip5_raw.json'
if hf.exists():
 b=hf.read_bytes(); h=json.loads(b)
 extra={'file':str(hf.relative_to(R)),'bytes':len(b),'sha256':sha(b),'compressed_roundtrip_byte_identical':zlib.decompress(base64.b64decode((P/'new_small.b64').read_bytes()))==b}
 old=json.loads((P/'pre_matrix_raw.json').read_text())
 fd=json.loads((P/'firm_dose_raw.json').read_text())
 extra['historical_technology_vs_original']=compare(rows(old['dose']),rows(h['historical_technology']),['unit','variant'],['source_families','pairs','citing_families','known_pairs','known_us_mass'])
 extra['historical_firms_vs_original']=compare(fd['rows'],rows(h['historical_firms']),['unit','variant'],['source_families','pairs','citing_families','known_pairs','known_us_mass'])
 ip5=[]
 for r in rows(h['ip5']):
  k,n,x=r['known_families'],r['families'],r['known_us_mass']
  r.update(B_known=x/k if k else None,conditional_lower=x/n if n else None,conditional_upper=(x+n-k)/n if n else None)
  ip5.append(r)
 extra['IP5_arithmetic']=ip5
 extra['IP5_point_ranges']={l:[min(r['B_known'] for r in ip5 if r['label']==l),max(r['B_known'] for r in ip5 if r['label']==l)] for l in ['positive','nonlisted']}
 extra['IP5_point_range_intersection']=[max(v[0] for v in extra['IP5_point_ranges'].values()),min(v[1] for v in extra['IP5_point_ranges'].values())]
 # Locate executed SQL by its exact recorded byte hash, not by filename guess.
 sqls={}
 for f in list(P.glob('*.sql'))+list(P.glob('*.json')):
  if f.suffix=='.sql':candidates=[f.read_text(encoding='utf-8')]
  else:
   try:candidates=list(strvalues(json.loads(f.read_text(encoding='utf-8'))))
   except Exception:continue
  for q in candidates:
   if 'SELECT' in q.upper():sqls.setdefault(sha(q.encode()),[]).append(str(f.relative_to(R)))
 extra['recorded_query_hash_locations']={k:{'utf8_query_string_sha256_after_LF_normalization':s,'matching_local_locations':sqls.get(s,[])} for k,s in h['query_shas'].items()}
 extra['actual_sql_file_byte_receipts']=[{'file':str(f.relative_to(R)),'bytes':len(f.read_bytes()),'file_bytes_sha256':sha(f.read_bytes()),'LF_normalized_text_sha256':sha(f.read_text(encoding='utf-8').encode())} for f in P.glob('*_actual.sql')]
 extra['actual_SQL_semantics_review']={'historical_technology':'TLS227 applicant country from dated2013-17 publications; selected application earliestpub2013-17; same final30rows as original. Original support/panel countries stillTLS207 latest.','historical_firms':'TLS227 exact name on dated2013-17 publication plus application earliestpub2013-17; same fixed2017legal subset; not proof of groupownership every year.','ip5':'family_map from all-authority current mergedIPC; eligible familyminimum application earliestpub2013-17; only applications firstpublishedby2017 counted for offices>=2 excludingWO,>=1IP5; earliestfamilypublication representative country fromTLS227. Not OECDseries identical.'}
 out['new_historical_and_IP5']=extra
 lines+=['새 파일 `'+extra['file']+'`: '+str(extra['bytes'])+' bytes, SHA256 `'+extra['sha256']+'`, b64 해제 byte 동일='+str(extra['compressed_roundtrip_byte_identical'])+'.',
 '','생산자의 TLS227 source 감도는 기술 30행이 원판과 수치상 완전히 같다. 기업은 BABA group/issuer, BIDU group, JD group에서 달라진다. 이는 역사 명의 선택의 중요성을 실제로 보이며 원판도 역사 명의였다는 증거가 아니다. 실제 SQL 해시와 로컬 원문 대응은 JSON에 별도 기록했다. Windows파일의 CRLF byte해시와 LF로 정규화한 실행SQL문자열의 UTF8해시는 별개로 기록했다.','',
 'EARLIEST_PUBLN_DATE는 application의 최초공개일이다(catalogp159). 원dose의source는 그날짜2013–17인 출원을 가진 family합집합이며 family첫공개cohort라고 부르면 안 된다. 반면 새IP5SQL은 family전체 MIN을 실제 구했다. 사전support·postpanel의국가연결은여전히TLS207latest이므로 과거공보당시국가로도지원결과가같다는검증은별도다.','',
 '| IP5 유사부분집합 단위 | family | 나라 확인 | B_known | 조건부 [lo,hi] |','|---|---:|---:|---:|---|']
 for r in ip5:lines.append(f"| {r['unit']} | {r['families']} | {r['known_families']} | {r['B_known']:.6f} | [{r['conditional_lower']:.6f},{r['conditional_upper']:.6f}] |")
 br=extra['IP5_point_ranges']; ins=extra['IP5_point_range_intersection']
 lines+=['',f"대안의 점 B 범위는 지목 [{br['positive'][0]:.9f},{br['positive'][1]:.9f}], 비지목 [{br['nonlisted'][0]:.9f},{br['nonlisted'][1]:.9f}], 교집합 [{ins[0]:.9f},{ins[1]:.9f}]. 이는 IP5 유사 포트폴리오의 일부 공통 범위이며 원 인용 B의 공통지지 실패를 자동 해결하지 않는다. 지원조건 P04만 통과라는 자료제약도 바뀌지 않는다.",
 '','[OECD 2019 Innovative outputs](https://www.oecd.org/en/publications/measuring-the-digital-transformation_9789264311992-en/full-report/component-42.html)의 정의는 2관청 이상 출원 + 최소1관청이IP5다. 같은 페이지 figure 주석은 applicant residence의 fractional count다. 따라서 지정 출처를 inventor 기준이라고 서술하면 부정확하다. [OECD 2024 Annex C](https://www.oecd.org/en/publications/promoting-the-growth-of-the-semiconductor-ecosystem-in-the-philippines_01497fea-en/full-report/notes-on-patent-data_f8ed0fa4.html)도 같은2관청/IP5 정의를 확인한다. 본 집계는 WO를 제외한 national/regional관청·2017까지공개조건·DOCDBfamily·distinct applicantcountry가중 등에서 지정 OECD그림과 다르다.']
out['supplement_status']='new historical/IP5 arithmetic verified; actual SQL semantics and LF-normalized execution hashes checked; independent DB response pending unless recorded below'
(V/'patstat_nov14.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
(V/'patstat_nov14.md').write_text(md+'\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.get('new_historical_and_IP5',{}).items() if k in ['sha256','historical_technology_vs_original','IP5_point_ranges','recorded_query_hash_locations']},ensure_ascii=False))
