"""Independent arithmetic, transport, and SQL-materialization audit.
No producer Python modules are imported; only recorded inputs are read.
"""
from pathlib import Path
import json, csv, hashlib, base64, zlib, itertools, datetime, math
V=Path(__file__).parent; R=V.parent; P=R/'patstat'
sha=lambda b:hashlib.sha256(b).hexdigest()
def receipt(f):
 b=f.read_bytes(); return {'path':str(f.relative_to(R)),'bytes':len(b),'sha256':sha(b)}
def rows(d):
 return [dict(zip(d['columns'],r)) for r in d['rows']]
pre=json.loads((P/'pre_matrix_raw.json').read_text(encoding='utf-8'))
firm=json.loads((P/'firm_dose_raw.json').read_text(encoding='utf-8'))
maps=list(csv.DictReader((R/'crosswalk/analysis_unit_map.csv').open(encoding='utf-8-sig')))
unitlabels={r['analysis_unit_merged_ai_am']:r['label'] for r in maps}
support=rows(pre['support']); dose=rows(pre['dose']); overlap=rows(pre['overlap'])
transport=[]
for n in ['pre_matrix','firm_dose']:
 raw=(P/(n+'_raw.json')).read_bytes()
 dec=zlib.decompress(base64.b64decode((P/(n+'.b64')).read_bytes()))
 transport.append(dict(receipt(P/(n+'_raw.json')),compressed_roundtrip_byte_identical=raw==dec,decoded_sha256=sha(dec)))
dataset='p-epo-tip-prj-3a1f.p_epo_tip_euwe4_bqd_patstatb'
names={'A':'tls201_appln','P':'tls206_person','PA':'tls207_pers_appln','I':'tls209_appln_ipc','PUB':'tls211_pat_publn','CIT':'tls212_citation','PP':'tls227_pers_publn'}
sqlchecks=[]
for n in ['support','dose','overlap']:
 q=(P/(n+'.sql')).read_text(encoding='utf-8')
 for key,table in names.items():q=q.replace('{'+key+'}',f'`{dataset}.{table}`')
 sqlchecks.append({'query':n,'rendered_sql_sha256':sha(q.encode()),'raw_recorded_sql_sha256':pre[n]['query_sha256'],'match':sha(q.encode())==pre[n]['query_sha256']})
si={(r['unit'],r['country'],r['year']):r for r in support}
support_summary=[]
for u,l in sorted(unitlabels.items()):
 cell=[si.get((u,c,y),{'families':0})['families'] for c,y in itertools.product(['CN','DE','JP','KR','US'],range(2010,2016))]
 support_summary.append({'unit':u,'label':l,'expected_cells':30,'observed_nonzero_cells':sum(v>0 for v in cell),'zero_cells':sum(v==0 for v in cell),'below_5_cells':sum(v<5 for v in cell),'minimum_families':min(cell),'passes_all_country_year_ge_5':min(cell)>=5})
def add_b(r):
 r=dict(r); n=r['pairs']; k=r['known_pairs']; x=r['known_us_mass']
 r.update(B_known=x/k if k else None,known_pair_share=k/n if n else None,
 conditional_missing_pair_lower=x/n if n else None,
 conditional_missing_pair_upper=(x+n-k)/n if n else None,
 missing_pair_bound_scope='Resolved family pairs with zero known applicant countries only; assumes observed shares correct for all other pairs. Excludes partially missing countries, unresolved citation links, NPL, source/entity/classification errors.')
 return r
dose_b=list(map(add_b,dose)); firm_b=list(map(add_b,firm['rows']))
eligible=[r for r in dose_b if r['variant']=='ALL' and r['known_pairs']>=20]
branges={l:[min(r['B_known'] for r in eligible if r['label']==l),max(r['B_known'] for r in eligible if r['label']==l)] for l in ['positive','nonlisted']}
invariants={
 'support_keys_unique':len(si)==len(support),
 'support_first_between_0_and_total':all(0<=r['first_families']<=r['families'] for r in support),
 'tech_pair_counts_consistent':all(0<=r['known_pairs']<=r['pairs'] and 0<=r['known_us_mass']<=r['known_pairs'] and r['citing_families']<=r['source_families'] for r in dose_b),
 'firm_pair_counts_consistent':all(0<=r['known_pairs']<=r['pairs'] and 0<=r['known_us_mass']<=r['known_pairs'] and r['citing_families']<=r['source_families'] for r in firm_b),
 'APP_not_larger_than_ALL':all(r['pairs']<=next(a['pairs'] for a in dose_b+firm_b if a['unit']==r['unit'] and a['variant']=='ALL') for r in dose_b+firm_b if r['variant']=='APP')}
sources=[
 {'url':'https://link.epo.org/web/observatory-tools/patstat/en-data-catalog-patsat-global-autumn-2026.pdf','title':'EPO PATSTAT Global catalog v5.28, 16 October 2026','locator':'pp27,57-58,62-63,78-79,115-120,127-130,150-151,155,159','local':'verification/patstat_sources/epo_patstat_global_2026b_catalog.pdf','sha256':sha((V/'patstat_sources/epo_patstat_global_2026b_catalog.pdf').read_bytes())},
 {'url':'https://www.epo.org/en/searching-for-patents/helpful-resources/patent-knowledge-news/improved-availability-citations','title':'EPO examination-citation workflow notice','locator':'EP applications from May 2021 versus earlier publications; not proof all citations retrospectively visible by citing pub date'},
 {'url':'https://www.sec.gov/Archives/edgar/data/1329099/000119312518084050/d480652d20f.htm','title':'Baidu 2017 Form20F','locator':'Note1 F9, browser lines4806-4814; BaiduPay demonstrates incomplete subset'},
 {'url':'https://www.sec.gov/Archives/edgar/data/1577552/000104746917004019/a2231121zex-8_1.htm','title':'Alibaba 2017 Exhibit8.1','locator':'significant subsidiaries AND consolidated entities, as of March31 2017; list longer than mapped subset'},
 {'url':'https://www.sec.gov/Archives/edgar/data/1577552/000104746917004019/a2231121z20-f.htm','title':'Alibaba 2017 Form20F','locator':'Item4C, browser lines3333,3353: Cloud VIE distinct from Zhejiang Cloud WFOE'},
 {'url':'https://www.sec.gov/Archives/edgar/data/1549802/000110465918027777/a18-5116_120f.htm','title':'JD 2017 Form20F','locator':'Note1 F12, browser lines6126-6142;100% subsidiaries; list contains omitted firms'},
 {'url':'https://www.sec.gov/Archives/edgar/data/1110646/000110465918025392/a18-5396_120f.htm','title':'NetEase 2017 Form20F','locator':'Note1 F7, browser lines5230-5248; omitted Youdao Information; VIE language ppF9-10'}]
findings=[
 {'id':'PV01','severity':'material_limitation','finding':'TLS207 selects latest Latin-name publication applicant records, not the 2013-2017 publication-specific applicant. Thus original source CN-address and firm-name selection is retrospective. Historical TLS227 sensitivity requested.','evidence':'catalog p57; build_queries.py wc/source and firm_dose_raw.json query'},
 {'id':'PV02','severity':'material_limitation','finding':'Country bounds are conditional on resolved family pairs and zero-known-country pairs; partially missing applicants, unresolved links and NPL are outside bounds. Country weights equal distinct known countries, not persons/nationalities.','evidence':'dose.sql target_country/d and pairdoc inner joins'},
 {'id':'PV03','severity':'material_limitation','finding':'TLS209 merges IPC from all publication instances and latest version. Exact crosswalk aliases do not reconstruct IPC assignment known in2017.','evidence':'catalog p58; crosswalk sql_exact_membership_union_2017_2026.csv'},
 {'id':'PV04','severity':'material_limitation','finding':'Source publication date before2018 does not itself prove each citation became available by2017; the raw citation table has origin phases rather than historical data-loading or citation-event timestamp in the query.','evidence':'catalog pp62-63,127-130; EPO examination citation workflow notice'},
 {'id':'PV05','severity':'scope','finding':'Four ADR group maps are confirmed legal-name subsets, not group census; 2017 snapshot does not prove ownership in every year2013-17. VIE is contractual consolidation, not issuer equity ownership.','evidence':'entity_map_2017.csv and linked SEC2017 reports'},
 {'id':'PV06','severity':'empirical_failure','finding':'Only P04 satisfies every one of30 five-country-year cells>=5; no nonlisted comparator passes. Point B ranges among ALL known_pairs>=20 do not overlap, but this does not establish nonoverlap of true B under country missingness.','evidence':'pre_matrix_raw.json independently recalculated'},
 {'id':'PV07','severity':'scope','finding':'Technology B uses CN-address WO applications; firm B uses all application authorities. Their slopes/cross-sectional values are different estimands.','evidence':'dose.sql members/wc vs firm_dose_raw.json source'},
 {'id':'PV08','severity':'needs_provenance','finding':'Dataset qualified name is observed in query, but metadata extraction code alone is not actual executed schema/provenance output. Edition2026b cannot be established solely from dataset suffix.','evidence':'init_metadata.py; local actual metadata pending'},
 {'id':'PV09','severity':'scope','finding':'APP denotes applicant-introduced citations and ALL mixes origin phases. Pair is APP if any qualifying citation to that target family is APP; common earliest target document is selected over ALL qualifying documents. Its applicant country may belong to another, non-APP cited document of same family. This is intentional common selection, not APP-only cited-document country.','evidence':'catalog p127; dose.sql pairdoc/pair/variants'}]
out={'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verifier':'independent nov14 PATSTAT verifier; producer=root','status':'arithmetic_and_transport_verified; independent database roundtrip pending','transport':transport,'query_hash_checks':sqlchecks,'invariants':invariants,'support_summary':support_summary,'support_pass_units':[r['unit'] for r in support_summary if r['passes_all_country_year_ge_5']],'B_point_ranges_ALL_known_pairs_ge20':branges,'B_point_ranges_overlap':max(branges['positive'][0],branges['nonlisted'][0])<=min(branges['positive'][1],branges['nonlisted'][1]),'zero_source_technology_units_absent_from_raw':sorted(set(unitlabels)-{r['unit'] for r in dose}),'firm_issuers_absent_from_raw':['BIDU_issuer','JD_issuer'],'technology_B':dose_b,'firm_B':firm_b,'overlap':overlap,'findings':findings,'primary_sources':sources,'input_receipts':[receipt(f) for f in [P/'build_queries.py',P/'queries.json',R/'crosswalk/analysis_unit_map.csv',R/'crosswalk/sql_exact_membership_union_2017_2026.csv',R/'market/entity_map_2017.csv',R/'protocol.md',V/'independent_queries.json',V/'independent_historical_queries.json']]}
(V/'patstat_nov14.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
lines=['# Nov14 PATSTAT 독립 검증','',
'판정: 수송 무결성·기록된 집계의 산술은 재현된다. 현재 자료로 비교기술의 충분한 지원, B 공통지지, 2017 당시 기업/국가 명의 또는 인과효과는 확인되지 않는다. 독립 SQL의 원DB 반환을 기다리는 중이며, 생산자 SQL 실행을 그대로 독립 원DB검증이라고 부르지 않는다.','',
'## 수행 범위와 무결성','',
'생산 코드는 실행·import하지 않고 CSV와 raw JSON을 직접 읽었다. UI는 생산자 전용으로 유지했다. 독립 쿼리는 법인/IPC CSV에서 다시 만들고 인용의 문헌 경로와 출원 경로를 나눈 뒤 window 순위로 family pair를 선택한다. 실제 실행은 로그인된 TIP을 제어하는 생산자에게 요청했다.','',
'| 입력 | bytes | SHA256 | b64 압축 해제 |','|---|---:|---|---|']
lines += [f"| {r['path']} | {r['bytes']} | `{r['sha256']}` | {'완전 동일' if r['compressed_roundtrip_byte_identical'] else '불일치'} |" for r in transport]
lines+=['',f"템플릿의 일곱 테이블 placeholder를 실제 dataset으로 치환한 support/dose/overlap SQL 해시와 raw 기록 일치: {all(r['match'] for r in sqlchecks)}. 일관성 점검: `{json.dumps(invariants,ensure_ascii=False)}`.",'','## 사전 지원과 B 공통지지','',
'사전 2010–2015 × CN/DE/JP/KR/US 30칸을 구성하고 raw에 없는 칸을 0으로 보충했다. source 미상이나 pair0를 B=0으로 바꾸지는 않았다.','',
'| 단위 | 분류 | 최소 family | 0인 칸 | 5 미만 칸 | 모든 칸 ≥5 |','|---|---|---:|---:|---:|---|']
lines += [f"| {r['unit']} | {r['label']} | {r['minimum_families']} | {r['zero_cells']} | {r['below_5_cells']} | {'통과' if r['passes_all_country_year_ge_5'] else '미달'} |" for r in support_summary]
lines += ['',f"통과는 {out['support_pass_units']}뿐이다. known_pairs≥20인 ALL에서 지목 B 범위 {branges['positive'][0]:.9f}–{branges['positive'][1]:.9f}, 비지목 {branges['nonlisted'][0]:.9f}–{branges['nonlisted'][1]:.9f}로 점추정 구간이 겹치지 않는다. 이 20쌍 기준은 추가 정밀도 진단이며 확증 cutoff가 아니다. 미상 나라에 관한 조건부 구간은 넓게 겹칠 수 있으므로 진실한 B도 겹치지 않는다는 결론은 아니다.",'',
'기술 dose raw에 N05/N07/N08 행이 없다. source_families가 없는 단위를 최종ns에서 만들지 않기 때문이다. B=0으로 복구하면 안 된다. 월별 패널을 만들 때도 0과 주소·분류 미상은 구별해야 한다.','',
'## 기업 B의 독립 산술','',
'각 수치는 네 ADR의 확인된 법인부분집합에 관한 것이다. 기업집단 전체의 기술손실이나 미국기술 사용의 진실값이 아니다. B_known=known_us_mass/known_pairs, 조건부 [lo,hi]=[mass/pairs,(mass+pairs-known_pairs)/pairs]. known_pairs=0이면 B_known은 미상, pairs=0이면 구간도 미상이다.','',
'| 명의 범위 | origin | source family | pair | 나라 확인 pair | B_known | 조건부 [lo,hi] |','|---|---|---:|---:|---:|---:|---|']
for r in firm_b:
 b='미상' if r['B_known'] is None else f"{r['B_known']:.6f}"
 bound='미상' if r['pairs']==0 else f"[{r['conditional_missing_pair_lower']:.6f},{r['conditional_missing_pair_upper']:.6f}]"
 lines.append(f"| {r['unit']} | {r['variant']} | {r['source_families']} | {r['pairs']} | {r['known_pairs']} | {b} | {bound} |")
lines+=['','BIDU/JD issuer 행은 원raw에서 아예 없으므로 issuer에 source가 없었다는 해석은 독립SQL에서 확인할 예정이다. NTES APP의 0 pair는 미국 의존도 0이 아니라 측정 불가다.','',
'## 코드·원문 감사에서 남은 핵심 제약','',
'1. **원 source의 시점 불일치:** TLS207는 최신 Latin-name 공보의 인명을 application에 연결한다. source공개일≤2017만으로 주소·법인명이 2017 공보 당시 것임을 보장하지 못한다. TLS227 공보별 명의로 새 감도를 준비했다. [EPO catalog](https://link.epo.org/web/observatory-tools/patstat/en-data-catalog-patsat-global-autumn-2026.pdf), p57.','',
'2. **재분류:** TLS209는 모든 공보의 IPC를 병합하고 최신 버전을 쓴다. 2017 alias crosswalk는 2017 당시의 실제 분류 부착정보까지 복원하지 않는다. 같은 원문 p58.','',
'3. **country bounds의 범위:** 일부 출원인의 나라가 비어도 다른 출원인의 나라 하나라도 있으면 known pair다. 따라서 위 구간은 모든 결측국가의 무조건 상하한이 아니다. distinct 나라를 동등 가중하므로 사람 수 가중도, 소유권·국적 가중도 아니다. target 해석은 TLS227 공보 명의에 한한다. 같은 원문 p78 및 dose.sql target_country.','',
'4. **인용 선택·배제:** source-target DOCDB family별 중복 제거와 자기 family 배제는 코드에 명시된다. target은 유효 공개일≤2017 중 가장 이른 문헌·최소id다. APP은 어느 qualifying 문헌에서라도 APP이면 포함되지만 target문헌은 ALL과 공통 선택한다. cited_publn_id가 양수면 그 문헌만 허용한다. 문헌 id가 없을 때만 cited_appln으로 후보를 확장한다. targetfamily 미상·target 미연결·기한 밖·NPL은 남은 pair 분모와 위 bounds에서 제외된다. 배제된 인용의 양은 현재 집계가 제공하지 않는다.','',
'5. **정보 가용 시점:** APP은 출원인이 도입한 인용이고 ALL은 심사·검색 등의 origin도 섞는다. source공보의 공개일만으로 인용이 실제 2017까지 공개·적재됐다고 확정할 수 없다. 공식 [EPO 인용 workflow 변경](https://www.epo.org/en/searching-for-patents/helpful-resources/patent-knowledge-news/improved-availability-citations)도 공보와 인용 가용 시점의 차이를 보여준다.','',
'6. **법인 지도는 부분집합:** Baidu Note1에는 미포함 BaiduPay가 있고, JD Note1·NetEase Note1·Alibaba Exhibit8.1에도 지도 밖의 법인이 있다. 본 검증에서 확인한 매핑 명칭/관계는 대체로 제시 원문과 맞는다. BABA Cloud VIE와 Zhejiang Cloud WFOE는 다른 이름이다. VIE 계약연결을 issuer 지분소유로 바꾸면 안 된다. 2017년말(Alibaba는3월말)의 법인관계는 2013–17년 내내 해당 관계였다는 증거가 아니다.','',
'7. **분모의 차이:** 기술 B는 CN 주소 WO, 기업 B는 해당 이름의 모든 관청 출원이다. 두 수치를 하나의 동일 B로 취급하거나 4기업 회귀를 확증으로 해석할 수 없다.','',
'8. **패널·공통지지·인과성:** 공통지지 실패와 기술별 빈약한 지원은 실제 자료의 제약이다. 다른 cutoff나 추정법 명칭으로 해결됐다고 판정하지 않는다. 기술 간 양 팔 중첩은 raw overlap에 실제 존재하며 full JSON에 보존했다.','',
'## 원문과 독립 실행 증거','',
'공식 catalog 원본: `verification/patstat_sources/epo_patstat_global_2026b_catalog.pdf`, SHA256 `'+sources[0]['sha256']+'`. 발췌 완전 페이지 텍스트: `verification/patstat_sources/catalog_relevant_pages.txt`. 공식문서2026b를 읽었다는 것과 쿼리dataset의release확정은 다르다. actual schema/provenance 반환은 아직 로컬에 없다.','',
'독립 쿼리 원본: `verification/build_independent_patstat_sql.py`; `verification/independent_queries.json` SHA256 `'+sha((V/'independent_queries.json').read_bytes())+'`; 원판과 별도인 역사공보source 감도는 `verification/independent_historical_queries.json` SHA256 `'+sha((V/'independent_historical_queries.json').read_bytes())+'`. 두 번들의 b64를 로그인 TIP으로 전송해 실행할 수 있다.','']
lines+=['- ['+s['title']+']('+s['url']+'): '+s['locator'] for s in sources[2:]]
lines+=['','현재 판정은 집계·산술 검증 완료, 독립 원DB 반환 대조 대기다. post패널/IP5 대안 및 TLS227 historical-source 생산결과는 도착 후 추가 기록한다.']
(V/'patstat_nov14.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps({'transport_ok':all(r['compressed_roundtrip_byte_identical'] for r in transport),'query_hashes_match':all(r['match'] for r in sqlchecks),'invariants':invariants,'support_pass':out['support_pass_units'],'B_ranges':branges,'status':out['status']},ensure_ascii=False))
