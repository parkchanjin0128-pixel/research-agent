"""Verifier-written alternate SQL. Reads maps, never imports producer SQL/code.
The authenticated TIP notebook should execute each SQL and save rows plus SQL SHA.
"""
from pathlib import Path
import csv, json, re, hashlib, base64, zlib
V=Path(__file__).parent
R=V.parent
dataset='p-epo-tip-prj-3a1f.p_epo_tip_euwe4_bqd_patstatb'
def t(n): return f'`{dataset}.{n}`'
A,P,PA,I,PUB,CIT,PP=map(t,['tls201_appln','tls206_person','tls207_pers_appln','tls209_appln_ipc','tls211_pat_publn','tls212_citation','tls227_pers_publn'])
def struct(rows,names):
 return ','.join('STRUCT('+','.join("'%s' AS %s"%(v,k) for k,v in zip(names,row))+')' for row in rows)
mc=list(csv.DictReader((R/'crosswalk/sql_exact_membership_union_2017_2026.csv').open(encoding='utf-8-sig')))
tech=[(r['group_id'],r['ipc_compact']) for r in mc if r['group_id'] in ['P04','N01']]
entity=list(csv.DictReader((R/'market/entity_map_2017.csv').open(encoding='utf-8-sig')))
fm=[]
for r in entity:
 if r['relationship_label']=='unconfirmed_alias': continue
 key=re.sub('[^A-Z0-9]','',r['entity_legal_name'].upper())
 keys=[key]+([key.replace('LIMITED','LTD')] if 'LIMITED' in key else [])
 for k in keys:
  fm.append((r['firm_id']+'_group',k))
  if r['relationship_label']=='issuer_exact': fm.append((r['firm_id']+'_issuer',k))
maps='WITH tech AS (SELECT * FROM UNNEST(['+struct(tech,['unit','code'])+'])), names AS (SELECT * FROM UNNEST(['+struct(sorted(set(fm)),['unit','namekey'])+']))'
techapps=f"""techapps AS (SELECT DISTINCT m.unit,a.appln_id,a.docdb_family_id,a.earliest_filing_date,a.earliest_publn_date
FROM {A} a JOIN {I} i USING(appln_id) JOIN tech m ON REPLACE(UPPER(i.ipc_class_symbol),' ','')=m.code
WHERE a.appln_auth='WO' AND a.docdb_family_id>0)"""
support=maps+', '+techapps+f"""
SELECT m.unit,TRIM(p.person_ctry_code) country,EXTRACT(YEAR FROM m.earliest_filing_date) year,COUNT(DISTINCT m.docdb_family_id) families
FROM techapps m JOIN {PA} x USING(appln_id) JOIN {P} p USING(person_id)
WHERE x.applt_seq_nr>0 AND TRIM(p.person_ctry_code) IN ('CN','DE','JP','KR','US')
 AND m.earliest_filing_date BETWEEN DATE'2010-01-01' AND DATE'2015-12-31'
 AND m.earliest_publn_date<=DATE_ADD(m.earliest_filing_date,INTERVAL 24 MONTH)
GROUP BY 1,2,3 ORDER BY 1,2,3"""
# Source construction is separate for tech and firms and retains empty issuers in final grid.
sources=maps+', '+techapps+f""", s AS (
 SELECT DISTINCT m.unit,m.appln_id,m.docdb_family_id FROM techapps m
 WHERE earliest_publn_date BETWEEN DATE'2013-01-01' AND DATE'2017-12-31'
 AND EXISTS (SELECT 1 FROM {PA} x JOIN {P} p USING(person_id) WHERE x.appln_id=m.appln_id AND x.applt_seq_nr>0 AND TRIM(p.person_ctry_code)='CN')
 UNION DISTINCT
 SELECT n.unit,a.appln_id,a.docdb_family_id FROM names n JOIN {P} p
 ON REGEXP_REPLACE(UPPER(p.person_name),r'[^A-Z0-9]','')=n.namekey
 JOIN {PA} x USING(person_id) JOIN {A} a USING(appln_id)
 WHERE x.applt_seq_nr>0 AND a.docdb_family_id>0 AND a.earliest_publn_date BETWEEN DATE'2013-01-01' AND DATE'2017-12-31'
), e AS (
 SELECT s.unit,s.docdb_family_id sf,c.cited_pat_publn_id,c.cited_appln_id,
 IF(REGEXP_CONTAINS(UPPER(c.citn_origin),r'(^|[^A-Z])APP([^A-Z]|$)'),1,0) app
 FROM s JOIN {PUB} sp USING(appln_id) JOIN {CIT} c ON c.pat_publn_id=sp.pat_publn_id
 WHERE sp.publn_date BETWEEN DATE'2013-01-01' AND DATE'2017-12-31'
), resolved AS (
 SELECT e.*,q.pat_publn_id td,q.publn_date,a.docdb_family_id tf
 FROM e JOIN {PUB} q ON q.pat_publn_id=e.cited_pat_publn_id JOIN {A} a ON a.appln_id=q.appln_id
 WHERE e.cited_pat_publn_id>0
 UNION ALL
 SELECT e.*,q.pat_publn_id td,q.publn_date,a.docdb_family_id tf
 FROM e JOIN {A} a ON a.appln_id=e.cited_appln_id JOIN {PUB} q ON q.appln_id=a.appln_id
 WHERE COALESCE(e.cited_pat_publn_id,0)=0
), ranked AS (
 SELECT unit,sf,tf,td,MAX(app) OVER (PARTITION BY unit,sf,tf) app,
 ROW_NUMBER() OVER (PARTITION BY unit,sf,tf ORDER BY publn_date,td) rn
 FROM resolved WHERE tf>0 AND tf<>sf AND publn_date BETWEEN DATE'1800-01-01' AND DATE'2017-12-31'
), countries AS (
 SELECT q.pat_publn_id td,COUNT(DISTINCT NULLIF(TRIM(p.person_ctry_code),'')) nc,
 MAX(IF(TRIM(p.person_ctry_code)='US',1,0)) nus
 FROM {PP} q JOIN {P} p USING(person_id)
 WHERE q.applt_seq_nr>0 AND q.pat_publn_id IN (SELECT td FROM ranked WHERE rn=1) GROUP BY 1
), grid AS (SELECT unit FROM tech UNION DISTINCT SELECT unit FROM names),
ns AS (SELECT unit,COUNT(DISTINCT docdb_family_id) source_families FROM s GROUP BY 1),
ag AS (SELECT r.unit,v variant,COUNT(*) pairs,COUNT(DISTINCT sf) citing_families,
COUNTIF(c.nc>0) known_pairs,SUM(IFNULL(SAFE_DIVIDE(c.nus,c.nc),0)) known_us_mass
FROM ranked r LEFT JOIN countries c USING(td) CROSS JOIN UNNEST(['ALL','APP']) v
WHERE rn=1 AND (v='ALL' OR app=1) GROUP BY 1,2)
SELECT g.unit,COALESCE(ns.source_families,0) source_families,v variant,COALESCE(ag.pairs,0) pairs,
COALESCE(ag.citing_families,0) citing_families,COALESCE(ag.known_pairs,0) known_pairs,COALESCE(ag.known_us_mass,0) known_us_mass
FROM grid g CROSS JOIN UNNEST(['ALL','APP']) v LEFT JOIN ns ON ns.unit=g.unit LEFT JOIN ag ON ag.unit=g.unit AND ag.variant=v
ORDER BY unit,variant"""
out={'support_P04_N01':support,'dose_P04_N01_and_four_ADRs':sources}
for n,sql in out.items(): (V/('independent_'+n+'.sql')).write_text(sql,encoding='utf-8')
blob=json.dumps(out,separators=(',',':')).encode()
(V/'independent_queries.json').write_bytes(blob)
(V/'independent_queries.b64').write_text(base64.b64encode(zlib.compress(blob,9)).decode(),encoding='ascii')
print(json.dumps({'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'b64_bytes':len((V/'independent_queries.b64').read_bytes()),'sql_sha256':{k:hashlib.sha256(v.encode()).hexdigest() for k,v in out.items()}}))
# New sensitivity uses publication-specific applicant identities, not TLS207 latest.
# The original two-query bundle stays byte-identical for the pending round-trip.
hist=sources.replace(
 f"AND EXISTS (SELECT 1 FROM {PA} x JOIN {P} p USING(person_id) WHERE x.appln_id=m.appln_id AND x.applt_seq_nr>0 AND TRIM(p.person_ctry_code)='CN')",
 f"AND EXISTS (SELECT 1 FROM {PUB} hp JOIN {PP} x ON x.pat_publn_id=hp.pat_publn_id JOIN {P} p USING(person_id) WHERE hp.appln_id=m.appln_id AND hp.publn_date BETWEEN DATE'2013-01-01' AND DATE'2017-12-31' AND x.applt_seq_nr>0 AND TRIM(p.person_ctry_code)='CN')"
).replace(
 f"JOIN {PA} x USING(person_id) JOIN {A} a USING(appln_id)\n WHERE x.applt_seq_nr>0 AND a.docdb_family_id>0 AND a.earliest_publn_date",
 f"JOIN {PP} x USING(person_id) JOIN {PUB} hp ON hp.pat_publn_id=x.pat_publn_id JOIN {A} a ON a.appln_id=hp.appln_id\n WHERE hp.publn_date BETWEEN DATE'2013-01-01' AND DATE'2017-12-31' AND x.applt_seq_nr>0 AND a.docdb_family_id>0 AND a.earliest_publn_date"
)
assert hist!=sources and ('JOIN '+PA+' x USING(person_id)') not in hist
(V/'independent_historical_source_dose.sql').write_text(hist,encoding='utf-8')
hblob=json.dumps({'historical_source_dose_P04_N01_and_four_ADRs':hist},separators=(',',':')).encode()
(V/'independent_historical_queries.json').write_bytes(hblob)
(V/'independent_historical_queries.b64').write_text(base64.b64encode(zlib.compress(hblob,9)).decode(),encoding='ascii')
print(json.dumps({'historical_bytes':len(hblob),'historical_sha256':hashlib.sha256(hblob).hexdigest(),'historical_b64_bytes':len((V/'independent_historical_queries.b64').read_bytes())}))
